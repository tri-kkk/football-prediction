import React from 'react'
import { Composition } from 'remotion'
import { ShortsVideo } from './ShortsVideo'
import { FPS, HEIGHT, WIDTH } from './theme'
import { buildTimeline } from './timeline'
import type { ShortsProps } from './types'

const SAMPLE: ShortsProps = {
  showLogos: false,
  bgm: '',
  backgrounds: {
    hook: null,
    matchup: null,
    pitcher: null,
    analysis: null,
    reveal: null,
    cta: null,
  },
  game: {
    id: 1,
    league: 'KBO',
    home: { ko: '한화 이글스', en: 'Hanwha Eagles', ab: 'HH', c1: '#FF6600', c2: '#000000', logo: '' },
    away: { ko: 'KIA 타이거즈', en: 'KIA Tigers', ab: 'KIA', c1: '#EA0029', c2: '#06141F', logo: '' },
    winRate: { home: 86, away: 14 },
    pick: { team: '한화 이글스', side: 'home', stars: 5, confidence: 86, grade: 'PICK' },
    pitchers: {
      home: { name: '류현진', era: 3.91, whip: 1.23, k: 84 },
      away: { name: '황동하', era: 4.9, whip: 1.49, k: 58 },
    },
    aiAnalysis:
      '류현진은 최근 5경기에서 평균 6이닝 2실점으로 안정적인 이닝 소화를 보여주고 있습니다. ' +
      '황동하는 좌타 상대 피안타율이 3할을 넘어 한화 상위 타선에 고전할 가능성이 큽니다.',
    matchTime: '2026-08-20T10:00:00.000Z',
    matchDate: '2026-08-20',
    status: 'scheduled',
  },
}

export const RemotionRoot: React.FC = () => (
  <Composition
    id="Shorts"
    component={ShortsVideo}
    fps={FPS}
    width={WIDTH}
    height={HEIGHT}
    defaultProps={SAMPLE}
    // 영상 길이는 경기 데이터에 따라 달라진다.
    // (AI 분석이 없으면 analysis 씬을 건너뛰므로 timeline 이 길이를 계산해 준다)
    calculateMetadata={({ props }) => ({
      durationInFrames: buildTimeline(props.game).total,
    })}
  />
)
