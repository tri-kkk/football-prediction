#!/usr/bin/env node
// scripts/render-shorts.mjs
//
// 승부예측 숏폼 자동 렌더링.
// shorts-data API 에서 경기를 가져와 경기별로 1080x1920 mp4 를 뽑는다.
// 화면 녹화가 없으므로 사람이 붙어 있을 필요가 없고, cron 에 그대로 걸 수 있다.
//
// 사용법:
//   node scripts/render-shorts.mjs --league=KBO --limit=3
//   node scripts/render-shorts.mjs --league=MLB --bgm=sport-energetic.mp3 --out=./out
//
// 환경변수:
//   SHORTS_BASE_URL   데이터를 가져올 origin (기본 http://localhost:3000)

import { bundle } from '@remotion/bundler'
import { renderMedia, selectComposition } from '@remotion/renderer'
import fs from 'node:fs/promises'
import path from 'node:path'
import { fileURLToPath } from 'node:url'

const __dirname = path.dirname(fileURLToPath(import.meta.url))
const ROOT = path.resolve(__dirname, '..')

const arg = (name, fallback) => {
  const hit = process.argv.find((a) => a.startsWith(`--${name}=`))
  return hit ? hit.split('=').slice(1).join('=') : fallback
}

const LEAGUE = arg('league', 'KBO')
const LIMIT = Number(arg('limit', '1'))
const BGM = arg('bgm', '')
const OUT_DIR = path.resolve(ROOT, arg('out', './out'))
const SHOW_LOGOS = arg('logos', 'false') === 'true'
const BASE_URL = process.env.SHORTS_BASE_URL || 'http://localhost:3000'
const BROWSER = process.env.REMOTION_BROWSER || null

// 씬별 배경 영상 (public/videos/). 파일이 없으면 자동으로 그라디언트 폴백.
const BACKGROUNDS = {
  hook: 'bg-hook.mp4',
  matchup: 'bg-matchup.mp4',
  pitcher: 'bg-pitcher.mp4',
  analysis: 'bg-analysis.mp4',
  reveal: 'bg-reveal.mp4',
  cta: 'bg-cta.mp4',
}

/** public/videos 에 실제로 존재하는 것만 남긴다 */
async function resolveBackgrounds() {
  const out = {}
  for (const [k, file] of Object.entries(BACKGROUNDS)) {
    try {
      await fs.access(path.join(ROOT, 'public', 'videos', file))
      out[k] = file
    } catch {
      out[k] = null
    }
  }
  return out
}

async function fetchGames() {
  const url = `${BASE_URL}/api/admin/shorts-data?league=${encodeURIComponent(LEAGUE)}`
  const r = await fetch(url, { cache: 'no-store' })
  if (!r.ok) throw new Error(`shorts-data ${r.status} — ${url}`)
  const j = await r.json()
  const games = Array.isArray(j?.games) ? j.games : []
  if (!games.length) throw new Error(`${LEAGUE} 예정 경기가 없습니다`)
  return games
}

const slug = (s) => String(s).replace(/[^\w가-힣]+/g, '_').slice(0, 40)

async function main() {
  await fs.mkdir(OUT_DIR, { recursive: true })

  const [games, backgrounds] = await Promise.all([fetchGames(), resolveBackgrounds()])
  const picked = games.slice(0, LIMIT)
  console.log(`▶ ${LEAGUE} · ${picked.length}경기 렌더링`)

  console.log('▶ 번들링...')
  const serveUrl = await bundle({
    entryPoint: path.join(ROOT, 'remotion', 'index.ts'),
    publicDir: path.join(ROOT, 'public'),
    onProgress: (p) => process.stdout.write(`\r  bundle ${p}%   `),
  })
  console.log('\n▶ 번들 완료')

  for (const game of picked) {
    const inputProps = { game, showLogos: SHOW_LOGOS, bgm: BGM, backgrounds }

    const composition = await selectComposition({
      serveUrl,
      id: 'Shorts',
      inputProps,
      browserExecutable: BROWSER,
    })

    const name = `${LEAGUE}_${slug(game.home.ko)}_vs_${slug(game.away.ko)}.mp4`
    const outputLocation = path.join(OUT_DIR, name)

    console.log(`▶ ${name}`)
    await renderMedia({
      composition,
      serveUrl,
      codec: 'h264',
      // 화질 핵심: crf 18 + slow preset. 구버전(crf 22 + veryfast) 대비 확연히 선명하다.
      crf: 18,
      x264Preset: 'slow',
      pixelFormat: 'yuv420p',
      jpegQuality: 95,
      outputLocation,
      inputProps,
      browserExecutable: BROWSER,
      concurrency: null,
      onProgress: ({ progress }) =>
        process.stdout.write(`\r  ${Math.round(progress * 100)}%   `),
    })
    console.log(`\n  ✓ ${outputLocation}`)
  }

  console.log('\n완료')
}

main().catch((e) => {
  console.error('\n렌더 실패:', e.message)
  process.exit(1)
})
