// remotion/daily/types.ts
// /api/admin/shorts-daily 응답과 1:1 대응

export interface DailyTeam {
  name: string
  logo: string
}

export interface DailyPick {
  matchId: string | number
  league: string
  leagueLabel: string
  home: DailyTeam
  away: DailyTeam
  pickSide: 'HOME' | 'DRAW' | 'AWAY'
  pickTeam: string
  probability: number
  stars: number
  matchTime: string
}

export interface DailyProps {
  date: string
  sport: 'football' | 'baseball'
  groupLabel: string
  /** 오늘 분석한 전체 경기 수 — "N경기 중 3경기 통과" 서사의 분모 */
  totalMatches: number
  picks: DailyPick[]
  bgm: string
  backgrounds: {
    opener?: string | null
    pick?: string | null
    summary?: string | null
    cta?: string | null
  }
}
