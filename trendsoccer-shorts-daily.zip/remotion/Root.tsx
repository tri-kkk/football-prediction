import React from 'react'
import { Composition } from 'remotion'
import { ShortsVideo } from './ShortsVideo'
import { DailyPicks, dailyDuration } from './daily/DailyPicks'
import { FPS, HEIGHT, WIDTH } from './theme'
import { buildTimeline } from './timeline'
import type { ShortsProps } from './types'
import type { DailyProps } from './daily/types'

// ── 포맷 D — 원 매치 딥다이브 (야구) ─────────────────────
const MATCH_SAMPLE: ShortsProps = {
  showLogos: false,
  bgm: '',
  backgrounds: { hook: null, matchup: null, pitcher: null, analysis: null, reveal: null, cta: null },
  game: {
    id: 1,
    league: 'KBO',
    home: { ko: '한화 이글스', en: 'Hanwha Eagles', ab: 'HH', c1: '#FF6600', c2: '#000000', logo: '' },
    away: { ko: 'KIA 타이거즈', en: 'KIA Tigers', ab: 'KIA', c1: '#EA0029', c2: '#06141F', logo: '' },
    winRate: { home: 86, away: 14 },
    pick: { team: '한화 이글스', side: 'home', stars: 5, confidence: 86, grade: 'PICK' },
    pitchers: {
      home: { name: '류현진', era: 3.91, whip: 1.23, k: 84 },
      away: { name: '황동하', era: 4.9, whip: 1.49, k: 58 },
    },
    aiAnalysis:
      '류현진은 최근 5경기에서 평균 6이닝 2실점으로 안정적인 이닝 소화를 보여주고 있습니다. ' +
      '황동하는 좌타 상대 피안타율이 3할을 넘어 한화 상위 타선에 고전할 가능성이 큽니다.',
    matchTime: '2026-08-20T10:00:00.000Z',
    matchDate: '2026-08-20',
    status: 'scheduled',
  },
}

// ── 포맷 A — 데일리 픽 리포트 ────────────────────────────
const L = (id: number) => `https://media.api-sports.io/football/teams/${id}.png`

const DAILY_SAMPLE: DailyProps = {
  date: '2026-08-20',
  sport: 'football',
  groupLabel: '유럽 축구',
  totalMatches: 18,
  bgm: '',
  backgrounds: { opener: null, pick: null, summary: null, cta: null },
  picks: [
    {
      matchId: 'a',
      league: 'PL',
      leagueLabel: '프리미어리그',
      home: { name: '맨체스터 시티', logo: L(50) },
      away: { name: '리버풀', logo: L(40) },
      pickSide: 'HOME',
      pickTeam: '맨체스터 시티',
      probability: 68,
      stars: 4,
      matchTime: '2026-08-20T14:30:00.000Z',
    },
    {
      matchId: 'b',
      league: 'PD',
      leagueLabel: '라리가',
      home: { name: '레알 마드리드', logo: L(541) },
      away: { name: '헤타페', logo: L(546) },
      pickSide: 'HOME',
      pickTeam: '레알 마드리드',
      probability: 74,
      stars: 5,
      matchTime: '2026-08-20T18:00:00.000Z',
    },
    {
      matchId: 'c',
      league: 'SA',
      leagueLabel: '세리에A',
      home: { name: '인터 밀란', logo: L(505) },
      away: { name: '토리노', logo: L(503) },
      pickSide: 'HOME',
      pickTeam: '인터 밀란',
      probability: 63,
      stars: 4,
      matchTime: '2026-08-20T18:45:00.000Z',
    },
  ],
}

export const RemotionRoot: React.FC = () => (
  <>
    {/* 포맷 A — 매일 */}
    <Composition
      id="DailyPicks"
      component={DailyPicks}
      fps={FPS}
      width={WIDTH}
      height={HEIGHT}
      defaultProps={DAILY_SAMPLE}
      calculateMetadata={({ props }) => ({
        durationInFrames: dailyDuration(props.picks.length),
      })}
    />

    {/* 포맷 D — 빅매치 딥다이브 */}
    <Composition
      id="Shorts"
      component={ShortsVideo}
      fps={FPS}
      width={WIDTH}
      height={HEIGHT}
      defaultProps={MATCH_SAMPLE}
      calculateMetadata={({ props }) => ({
        durationInFrames: buildTimeline(props.game).total,
      })}
    />
  </>
)
