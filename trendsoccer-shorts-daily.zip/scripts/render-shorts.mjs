#!/usr/bin/env node
// scripts/render-shorts.mjs
//
// 승부예측 숏폼 자동 렌더링.
// shorts-data API 에서 경기를 가져와 경기별로 1080x1920 mp4 를 뽑는다.
// 화면 녹화가 없으므로 사람이 붙어 있을 필요가 없고, cron 에 그대로 걸 수 있다.
//
// 사용법:
//   # 포맷 A — 데일리 픽 리포트 (매일)
//   node scripts/render-shorts.mjs --format=daily --sport=football --group=euro
//   node scripts/render-shorts.mjs --format=daily --sport=football --group=kleague
//   node scripts/render-shorts.mjs --format=daily --sport=baseball --league=KBO
//
//   # 포맷 D — 빅매치 딥다이브
//   node scripts/render-shorts.mjs --format=match --league=KBO --limit=3
//
// 환경변수:
//   SHORTS_BASE_URL   데이터를 가져올 origin (기본 http://localhost:3000)

import { bundle } from '@remotion/bundler'
import { renderMedia, selectComposition } from '@remotion/renderer'
import fs from 'node:fs/promises'
import path from 'node:path'
import { fileURLToPath } from 'node:url'

const __dirname = path.dirname(fileURLToPath(import.meta.url))
const ROOT = path.resolve(__dirname, '..')

const arg = (name, fallback) => {
  const hit = process.argv.find((a) => a.startsWith(`--${name}=`))
  return hit ? hit.split('=').slice(1).join('=') : fallback
}

const FORMAT = arg('format', 'match')       // daily | match
const SPORT = arg('sport', 'football')      // daily 전용: football | baseball
const GROUP = arg('group', 'euro')          // daily + football 전용: euro | kleague | jleague
const COUNT = Number(arg('count', '3'))     // daily 전용: 픽 개수
const LEAGUE = arg('league', 'KBO')
const LIMIT = Number(arg('limit', '1'))
const BGM = arg('bgm', '')
const OUT_DIR = path.resolve(ROOT, arg('out', './out'))
const SHOW_LOGOS = arg('logos', 'false') === 'true'
const BASE_URL = process.env.SHORTS_BASE_URL || 'http://localhost:3000'
const BROWSER = process.env.REMOTION_BROWSER || null

// 씬별 배경 영상 (public/videos/). 파일이 없으면 자동으로 그라디언트 폴백.
const BACKGROUNDS_MATCH = {
  hook: 'bg-hook.mp4',
  matchup: 'bg-matchup.mp4',
  pitcher: 'bg-pitcher.mp4',
  analysis: 'bg-analysis.mp4',
  reveal: 'bg-reveal.mp4',
  cta: 'bg-cta.mp4',
}

const BACKGROUNDS_DAILY = {
  opener: 'bg-opener.mp4',
  pick: 'bg-pick.mp4',
  summary: 'bg-summary.mp4',
  cta: 'bg-cta.mp4',
}

const BACKGROUNDS = FORMAT === 'daily' ? BACKGROUNDS_DAILY : BACKGROUNDS_MATCH

/** public/videos 에 실제로 존재하는 것만 남긴다 */
async function resolveBackgrounds() {
  const out = {}
  for (const [k, file] of Object.entries(BACKGROUNDS)) {
    try {
      await fs.access(path.join(ROOT, 'public', 'videos', file))
      out[k] = file
    } catch {
      out[k] = null
    }
  }
  return out
}

async function fetchGames() {
  const url = `${BASE_URL}/api/admin/shorts-data?league=${encodeURIComponent(LEAGUE)}`
  const r = await fetch(url, { cache: 'no-store' })
  if (!r.ok) throw new Error(`shorts-data ${r.status} — ${url}`)
  const j = await r.json()
  const games = Array.isArray(j?.games) ? j.games : []
  if (!games.length) throw new Error(`${LEAGUE} 예정 경기가 없습니다`)
  return games
}

async function fetchDaily() {
  const qs =
    SPORT === 'baseball'
      ? `sport=baseball&league=${encodeURIComponent(LEAGUE)}&count=${COUNT}`
      : `sport=football&group=${encodeURIComponent(GROUP)}&count=${COUNT}`
  const url = `${BASE_URL}/api/admin/shorts-daily?${qs}`
  const r = await fetch(url, { cache: 'no-store' })
  if (!r.ok) throw new Error(`shorts-daily ${r.status} — ${url}`)
  const j = await r.json()
  if (!j.success) throw new Error(j.error || 'shorts-daily 실패')
  if (!Array.isArray(j.picks) || j.picks.length === 0) {
    throw new Error('오늘 조건을 통과한 픽이 없습니다 (영상 생성 스킵)')
  }
  return j
}

/**
 * 팀 로고를 미리 받아 data URI 로 바꿔 넣는다.
 *
 * 렌더 중에 외부 URL 을 그대로 물리면 Remotion 이 프레임마다 이미지를 기다리고,
 * URL 이 죽어 있으면 매 프레임 네트워크 타임아웃을 먹어 렌더가 10배 이상 느려진다.
 * 폰트를 인라인한 것과 같은 이유다. 실패한 로고는 빈 문자열로 두면
 * 컴포넌트가 팀명 이니셜 크레스트로 폴백한다.
 */
async function inlineLogos(picks) {
  const cache = new Map()

  const toDataUri = async (url) => {
    if (!url) return ''
    if (cache.has(url)) return cache.get(url)
    try {
      const r = await fetch(url, { signal: AbortSignal.timeout(8000) })
      if (!r.ok) throw new Error(String(r.status))
      const buf = Buffer.from(await r.arrayBuffer())
      const mime = r.headers.get('content-type') || 'image/png'
      const uri = `data:${mime};base64,${buf.toString('base64')}`
      cache.set(url, uri)
      return uri
    } catch {
      cache.set(url, '')
      return ''
    }
  }

  const out = []
  for (const p of picks) {
    out.push({
      ...p,
      home: { ...p.home, logo: await toDataUri(p.home.logo) },
      away: { ...p.away, logo: await toDataUri(p.away.logo) },
    })
  }

  const ok = out.filter((p) => p.home.logo && p.away.logo).length
  console.log(`▶ 로고 인라인: ${ok}/${out.length} 경기 성공 (실패분은 팀명 크레스트로 대체)`)
  return out
}

const slug = (s) => String(s).replace(/[^\w가-힣]+/g, '_').slice(0, 40)

async function main() {
  await fs.mkdir(OUT_DIR, { recursive: true })

  console.log('▶ 번들링...')
  const serveUrl = await bundle({
    entryPoint: path.join(ROOT, 'remotion', 'index.ts'),
    publicDir: path.join(ROOT, 'public'),
    onProgress: (p) => process.stdout.write(`\r  bundle ${p}%   `),
  })
  console.log('\n▶ 번들 완료')

  const backgrounds = await resolveBackgrounds()

  const render = async (compositionId, inputProps, name) => {
    const composition = await selectComposition({
      serveUrl,
      id: compositionId,
      inputProps,
      browserExecutable: BROWSER,
    })
    const outputLocation = path.join(OUT_DIR, name)
    console.log(`▶ ${name}`)
    await renderMedia({
      composition,
      serveUrl,
      codec: 'h264',
      // 화질 핵심: crf 18 + slow preset. 구버전(crf 22 + veryfast) 대비 확연히 선명하다.
      crf: 18,
      x264Preset: 'slow',
      pixelFormat: 'yuv420p',
      jpegQuality: 95,
      outputLocation,
      inputProps,
      browserExecutable: BROWSER,
      concurrency: null,
      onProgress: ({ progress }) => process.stdout.write(`\r  ${Math.round(progress * 100)}%   `),
    })
    console.log(`\n  ✓ ${outputLocation}`)
  }

  if (FORMAT === 'daily') {
    const data = await fetchDaily()
    console.log(`▶ ${data.groupLabel} · ${data.totalMatches}경기 중 ${data.picks.length}개 픽`)
    data.picks = await inlineLogos(data.picks)
    const tag = SPORT === 'baseball' ? LEAGUE : GROUP
    await render(
      'DailyPicks',
      { ...data, bgm: BGM, backgrounds },
      `daily_${tag}_${data.date}.mp4`
    )
  } else {
    const games = await fetchGames()
    const picked = games.slice(0, LIMIT)
    console.log(`▶ ${LEAGUE} · ${picked.length}경기 렌더링`)
    for (const game of picked) {
      await render(
        'Shorts',
        { game, showLogos: SHOW_LOGOS, bgm: BGM, backgrounds },
        `${LEAGUE}_${slug(game.home.ko)}_vs_${slug(game.away.ko)}.mp4`
      )
    }
  }

  console.log('\n완료')
}

main().catch((e) => {
  console.error('\n렌더 실패:', e.message)
  process.exit(1)
})
