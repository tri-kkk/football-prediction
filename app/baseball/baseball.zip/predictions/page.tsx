'use client'

import { useState, useEffect } from 'react'
import Link from 'next/link'
import { useLanguage } from '../../contexts/LanguageContext'

// =====================================================
// 타입 정의
// =====================================================
interface Match {
  id: number
  league: string
  leagueName: string
  date: string
  time: string
  timestamp: string
  homeTeam: string
  homeTeamKo: string
  homeLogo: string
  homeScore: number | null
  awayTeam: string
  awayTeamKo: string
  awayLogo: string
  awayScore: number | null
  status: string
  odds: {
    homeWinProb: number
    awayWinProb: number
    homeWinOdds: number
    awayWinOdds: number
    overUnderLine: number
    overOdds: number
    underOdds: number
  } | null
}

interface PredictionResult {
  match: Match
  prediction: {
    homeWinProb: number
    awayWinProb: number
    recommendedBet: 'HOME' | 'AWAY' | 'NONE'
    confidence: number
    grade: 'PICK' | 'GOOD' | 'PASS'
    reason: string
    reasonEn: string
  }
}

// =====================================================
// 상수
// =====================================================
const LEAGUES = [
  { id: 'ALL', name: '전체', nameEn: 'All' },
  { id: 'KBO', name: 'KBO', nameEn: 'KBO' },
  { id: 'MLB', name: 'MLB', nameEn: 'MLB' },
  { id: 'NPB', name: 'NPB', nameEn: 'NPB' },
  { id: 'CPBL', name: 'CPBL', nameEn: 'CPBL' },
]

const LEAGUE_COLORS: Record<string, string> = {
  KBO: 'bg-red-500',
  NPB: 'bg-orange-500',
  MLB: 'bg-blue-600',
  CPBL: 'bg-purple-500',
}

// =====================================================
// 샘플 데이터 (비시즌용)
// =====================================================
const SAMPLE_MATCHES: Match[] = [
  {
    id: 1001,
    league: 'KBO',
    leagueName: 'KBO League',
    date: '2025-03-22',
    time: '14:00',
    timestamp: '2025-03-22T05:00:00Z',
    homeTeam: 'LG Twins',
    homeTeamKo: 'LG 트윈스',
    homeLogo: 'https://media.api-sports.io/baseball/teams/3916.png',
    homeScore: null,
    awayTeam: 'Samsung Lions',
    awayTeamKo: '삼성 라이온즈',
    awayLogo: 'https://media.api-sports.io/baseball/teams/3920.png',
    awayScore: null,
    status: 'scheduled',
    odds: { homeWinProb: 62, awayWinProb: 38, homeWinOdds: 1.55, awayWinOdds: 2.45, overUnderLine: 8.5, overOdds: 1.9, underOdds: 1.9 }
  },
  {
    id: 1002,
    league: 'KBO',
    leagueName: 'KBO League',
    date: '2025-03-22',
    time: '14:00',
    timestamp: '2025-03-22T05:00:00Z',
    homeTeam: 'Doosan Bears',
    homeTeamKo: '두산 베어스',
    homeLogo: 'https://media.api-sports.io/baseball/teams/3912.png',
    homeScore: null,
    awayTeam: 'KIA Tigers',
    awayTeamKo: 'KIA 타이거즈',
    awayLogo: 'https://media.api-sports.io/baseball/teams/3915.png',
    awayScore: null,
    status: 'scheduled',
    odds: { homeWinProb: 55, awayWinProb: 45, homeWinOdds: 1.75, awayWinOdds: 2.05, overUnderLine: 9.0, overOdds: 1.85, underOdds: 1.95 }
  },
  {
    id: 1003,
    league: 'KBO',
    leagueName: 'KBO League',
    date: '2025-03-22',
    time: '17:00',
    timestamp: '2025-03-22T08:00:00Z',
    homeTeam: 'SSG Landers',
    homeTeamKo: 'SSG 랜더스',
    homeLogo: 'https://media.api-sports.io/baseball/teams/3921.png',
    homeScore: null,
    awayTeam: 'NC Dinos',
    awayTeamKo: 'NC 다이노스',
    awayLogo: 'https://media.api-sports.io/baseball/teams/3919.png',
    awayScore: null,
    status: 'scheduled',
    odds: { homeWinProb: 48, awayWinProb: 52, homeWinOdds: 2.0, awayWinOdds: 1.8, overUnderLine: 8.0, overOdds: 1.9, underOdds: 1.9 }
  },
  {
    id: 2001,
    league: 'MLB',
    leagueName: 'MLB',
    date: '2025-03-22',
    time: '19:10',
    timestamp: '2025-03-22T23:10:00Z',
    homeTeam: 'New York Yankees',
    homeTeamKo: '뉴욕 양키스',
    homeLogo: 'https://media.api-sports.io/baseball/teams/1.png',
    homeScore: null,
    awayTeam: 'Boston Red Sox',
    awayTeamKo: '보스턴 레드삭스',
    awayLogo: 'https://media.api-sports.io/baseball/teams/2.png',
    awayScore: null,
    status: 'scheduled',
    odds: { homeWinProb: 58, awayWinProb: 42, homeWinOdds: 1.65, awayWinOdds: 2.25, overUnderLine: 9.5, overOdds: 1.9, underOdds: 1.9 }
  },
  {
    id: 2002,
    league: 'MLB',
    leagueName: 'MLB',
    date: '2025-03-22',
    time: '22:05',
    timestamp: '2025-03-23T02:05:00Z',
    homeTeam: 'Los Angeles Dodgers',
    homeTeamKo: 'LA 다저스',
    homeLogo: 'https://media.api-sports.io/baseball/teams/20.png',
    homeScore: null,
    awayTeam: 'San Diego Padres',
    awayTeamKo: '샌디에이고 파드리스',
    awayLogo: 'https://media.api-sports.io/baseball/teams/25.png',
    awayScore: null,
    status: 'scheduled',
    odds: { homeWinProb: 72, awayWinProb: 28, homeWinOdds: 1.35, awayWinOdds: 3.1, overUnderLine: 8.5, overOdds: 1.85, underOdds: 1.95 }
  },
  {
    id: 3001,
    league: 'NPB',
    leagueName: 'NPB',
    date: '2025-03-22',
    time: '14:00',
    timestamp: '2025-03-22T05:00:00Z',
    homeTeam: 'Yomiuri Giants',
    homeTeamKo: '요미우리 자이언츠',
    homeLogo: 'https://media.api-sports.io/baseball/teams/287.png',
    homeScore: null,
    awayTeam: 'Hanshin Tigers',
    awayTeamKo: '한신 타이거스',
    awayLogo: 'https://media.api-sports.io/baseball/teams/282.png',
    awayScore: null,
    status: 'scheduled',
    odds: { homeWinProb: 52, awayWinProb: 48, homeWinOdds: 1.88, awayWinOdds: 1.92, overUnderLine: 7.5, overOdds: 1.9, underOdds: 1.9 }
  },
  {
    id: 3002,
    league: 'NPB',
    leagueName: 'NPB',
    date: '2025-03-22',
    time: '18:00',
    timestamp: '2025-03-22T09:00:00Z',
    homeTeam: 'SoftBank Hawks',
    homeTeamKo: '소프트뱅크 호크스',
    homeLogo: 'https://media.api-sports.io/baseball/teams/286.png',
    homeScore: null,
    awayTeam: 'Orix Buffaloes',
    awayTeamKo: '오릭스 버팔로스',
    awayLogo: 'https://media.api-sports.io/baseball/teams/284.png',
    awayScore: null,
    status: 'scheduled',
    odds: { homeWinProb: 65, awayWinProb: 35, homeWinOdds: 1.5, awayWinOdds: 2.6, overUnderLine: 8.0, overOdds: 1.9, underOdds: 1.9 }
  },
  {
    id: 4001,
    league: 'CPBL',
    leagueName: 'CPBL',
    date: '2025-03-22',
    time: '18:35',
    timestamp: '2025-03-22T10:35:00Z',
    homeTeam: 'Rakuten Monkeys',
    homeTeamKo: '라쿠텐 몽키스',
    homeLogo: 'https://media.api-sports.io/baseball/teams/4817.png',
    homeScore: null,
    awayTeam: 'Uni-Lions',
    awayTeamKo: '유니 라이온즈',
    awayLogo: 'https://media.api-sports.io/baseball/teams/4818.png',
    awayScore: null,
    status: 'scheduled',
    odds: { homeWinProb: 56, awayWinProb: 44, homeWinOdds: 1.72, awayWinOdds: 2.1, overUnderLine: 8.5, overOdds: 1.9, underOdds: 1.9 }
  },
]

// =====================================================
// 유틸리티 함수
// =====================================================

function calculatePrediction(match: Match): PredictionResult['prediction'] {
  const odds = match.odds
  
  if (!odds) {
    return {
      homeWinProb: 50,
      awayWinProb: 50,
      recommendedBet: 'NONE',
      confidence: 0,
      grade: 'PASS',
      reason: '배당 정보 없음',
      reasonEn: 'No odds data'
    }
  }
  
  const homeProb = odds.homeWinProb
  const awayProb = odds.awayWinProb
  const diff = Math.abs(homeProb - awayProb)
  
  let confidence = Math.min(diff * 1.5, 95)
  let grade: 'PICK' | 'GOOD' | 'PASS' = 'PASS'
  let recommendedBet: 'HOME' | 'AWAY' | 'NONE' = 'NONE'
  let reason = ''
  let reasonEn = ''
  
  if (diff >= 20) {
    grade = 'PICK'
    confidence = Math.min(confidence + 10, 95)
    recommendedBet = homeProb > awayProb ? 'HOME' : 'AWAY'
    reason = homeProb > awayProb ? '홈팀 압도적 우세' : '원정팀 압도적 우세'
    reasonEn = homeProb > awayProb ? 'Home team dominant' : 'Away team dominant'
  } else if (diff >= 10) {
    grade = 'GOOD'
    recommendedBet = homeProb > awayProb ? 'HOME' : 'AWAY'
    reason = homeProb > awayProb ? '홈팀 우세 예상' : '원정팀 우세 예상'
    reasonEn = homeProb > awayProb ? 'Home team favored' : 'Away team favored'
  } else {
    grade = 'PASS'
    reason = '접전 예상 - 신중한 접근 필요'
    reasonEn = 'Close match - proceed with caution'
  }
  
  return {
    homeWinProb: homeProb,
    awayWinProb: awayProb,
    recommendedBet,
    confidence: Math.round(confidence),
    grade,
    reason,
    reasonEn
  }
}

function formatDate(dateStr: string, lang: 'ko' | 'en'): string {
  const date = new Date(dateStr)
  if (lang === 'ko') {
    return date.toLocaleDateString('ko-KR', { month: 'short', day: 'numeric', weekday: 'short' })
  }
  return date.toLocaleDateString('en-US', { month: 'short', day: 'numeric', weekday: 'short' })
}

// =====================================================
// 컴포넌트
// =====================================================

function TeamLogo({ src, team, size = 'md' }: { src?: string; team: string; size?: 'sm' | 'md' | 'lg' }) {
  const sizeClasses = {
    sm: 'w-8 h-8 text-xs',
    md: 'w-12 h-12 text-sm',
    lg: 'w-16 h-16 text-base',
  }
  
  if (src) {
    return (
      <img 
        src={src} 
        alt={team} 
        className={`${sizeClasses[size]} object-contain`}
        onError={(e) => {
          (e.target as HTMLImageElement).style.display = 'none'
        }}
      />
    )
  }
  
  return (
    <div className={`${sizeClasses[size]} rounded-full bg-gray-200 flex items-center justify-center font-bold text-gray-500`}>
      {team.substring(0, 2)}
    </div>
  )
}

function GradeBadge({ grade }: { grade: 'PICK' | 'GOOD' | 'PASS' }) {
  const styles = {
    PICK: 'bg-gradient-to-r from-yellow-400 to-orange-500 text-white shadow-lg animate-pulse',
    GOOD: 'bg-gradient-to-r from-emerald-400 to-green-500 text-white',
    PASS: 'bg-gray-300 text-gray-600',
  }
  
  return (
    <span className={`px-3 py-1 rounded-full text-xs font-bold ${styles[grade]}`}>
      {grade}
    </span>
  )
}

function PredictionCard({ 
  match, 
  prediction, 
  language,
  isSample = false
}: { 
  match: Match
  prediction: PredictionResult['prediction']
  language: 'ko' | 'en'
  isSample?: boolean
}) {
  const homeTeamName = language === 'ko' ? match.homeTeamKo || match.homeTeam : match.homeTeam
  const awayTeamName = language === 'ko' ? match.awayTeamKo || match.awayTeam : match.awayTeam
  
  return (
    <div className={`bg-white rounded-2xl shadow-lg overflow-hidden border border-gray-100 hover:shadow-xl transition-shadow ${isSample ? 'opacity-90' : ''}`}>
      {/* 헤더 */}
      <div className="flex items-center justify-between px-4 py-2 bg-gray-50 border-b border-gray-100">
        <div className="flex items-center gap-2">
          <span className={`px-2 py-0.5 rounded text-xs font-bold text-white ${LEAGUE_COLORS[match.league] || 'bg-gray-500'}`}>
            {match.league}
          </span>
          <span className="text-xs text-gray-500">
            {formatDate(match.date, language)} {match.time}
          </span>
          {isSample && (
            <span className="px-1.5 py-0.5 bg-blue-100 text-blue-600 text-[10px] rounded font-medium">
              SAMPLE
            </span>
          )}
        </div>
        <GradeBadge grade={prediction.grade} />
      </div>
      
      {/* 팀 매치업 */}
      <div className="p-4">
        <div className="flex items-center justify-between mb-4">
          <div className="flex-1 text-center">
            <div className="flex justify-center">
              <TeamLogo src={match.homeLogo} team={match.homeTeam} size="lg" />
            </div>
            <p className="mt-2 font-bold text-gray-800 text-sm line-clamp-1">{homeTeamName}</p>
            <p className="text-xs text-gray-400">{language === 'ko' ? '홈' : 'Home'}</p>
          </div>
          
          <div className="px-4">
            <span className="text-2xl font-bold text-gray-300">VS</span>
          </div>
          
          <div className="flex-1 text-center">
            <div className="flex justify-center">
              <TeamLogo src={match.awayLogo} team={match.awayTeam} size="lg" />
            </div>
            <p className="mt-2 font-bold text-gray-800 text-sm line-clamp-1">{awayTeamName}</p>
            <p className="text-xs text-gray-400">{language === 'ko' ? '원정' : 'Away'}</p>
          </div>
        </div>
        
        {/* AI 예측 확률 바 */}
        <div className="mb-4">
          <div className="flex justify-between text-xs font-medium mb-1">
            <span className="text-blue-600">{prediction.homeWinProb}%</span>
            <span className="text-gray-400">{language === 'ko' ? 'AI 예측' : 'AI Prediction'}</span>
            <span className="text-red-500">{prediction.awayWinProb}%</span>
          </div>
          <div className="h-3 bg-gray-200 rounded-full overflow-hidden flex">
            <div 
              className="bg-gradient-to-r from-blue-500 to-blue-400 transition-all duration-500"
              style={{ width: `${prediction.homeWinProb}%` }}
            />
            <div 
              className="bg-gradient-to-r from-red-400 to-red-500 transition-all duration-500"
              style={{ width: `${prediction.awayWinProb}%` }}
            />
          </div>
        </div>
        
        {/* 추천 & 신뢰도 */}
        {prediction.recommendedBet !== 'NONE' && (
          <div className="bg-gradient-to-r from-emerald-50 to-green-50 rounded-xl p-3 border border-emerald-100">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs text-gray-500 mb-1">
                  {language === 'ko' ? '📊 AI 추천' : '📊 AI Pick'}
                </p>
                <p className="font-bold text-emerald-700">
                  {prediction.recommendedBet === 'HOME' ? homeTeamName : awayTeamName}
                  <span className="text-xs font-normal text-gray-500 ml-1">
                    {language === 'ko' ? '승' : 'Win'}
                  </span>
                </p>
              </div>
              <div className="text-right">
                <p className="text-xs text-gray-500 mb-1">
                  {language === 'ko' ? '신뢰도' : 'Confidence'}
                </p>
                <p className="font-bold text-emerald-600">{prediction.confidence}%</p>
              </div>
            </div>
            <p className="text-xs text-gray-500 mt-2 pt-2 border-t border-emerald-100">
              💡 {language === 'ko' ? prediction.reason : prediction.reasonEn}
            </p>
          </div>
        )}
        
        {prediction.recommendedBet === 'NONE' && (
          <div className="bg-gray-50 rounded-xl p-3 text-center">
            <p className="text-sm text-gray-500">
              ⚠️ {language === 'ko' ? prediction.reason : prediction.reasonEn}
            </p>
          </div>
        )}
      </div>
      
      {/* 푸터 */}
      <Link 
        href={`/baseball/${match.id}`}
        className="block px-4 py-3 bg-gray-50 text-center text-sm font-medium text-emerald-600 hover:bg-emerald-50 transition-colors border-t border-gray-100"
      >
        {language === 'ko' ? '상세 분석 보기 →' : 'View Details →'}
      </Link>
    </div>
  )
}

// =====================================================
// 메인 페이지 컴포넌트
// =====================================================
export default function BaseballPredictionsPage() {
  const { language } = useLanguage()
  const [selectedLeague, setSelectedLeague] = useState('ALL')
  const [matches, setMatches] = useState<Match[]>([])
  const [loading, setLoading] = useState(true)
  const [predictions, setPredictions] = useState<PredictionResult[]>([])
  const [usingSampleData, setUsingSampleData] = useState(false)
  
  // 경기 데이터 로드
  useEffect(() => {
    const fetchMatches = async () => {
      setLoading(true)
      try {
        const params = new URLSearchParams()
        if (selectedLeague !== 'ALL') {
          params.append('league', selectedLeague)
        }
        params.append('limit', '30')
        
        const response = await fetch(`/api/baseball/matches?${params}`)
        const data = await response.json()
        
        if (data.success && data.matches && data.matches.length > 0) {
          setMatches(data.matches)
          setUsingSampleData(false)
          
          const preds = data.matches.map((match: Match) => ({
            match,
            prediction: calculatePrediction(match)
          }))
          
          preds.sort((a: PredictionResult, b: PredictionResult) => {
            const gradeOrder = { PICK: 0, GOOD: 1, PASS: 2 }
            return gradeOrder[a.prediction.grade] - gradeOrder[b.prediction.grade]
          })
          
          setPredictions(preds)
        } else {
          // API에서 데이터 없으면 샘플 데이터 사용
          const filteredSamples = selectedLeague === 'ALL' 
            ? SAMPLE_MATCHES 
            : SAMPLE_MATCHES.filter(m => m.league === selectedLeague)
          
          setMatches(filteredSamples)
          setUsingSampleData(true)
          
          const preds = filteredSamples.map((match: Match) => ({
            match,
            prediction: calculatePrediction(match)
          }))
          
          preds.sort((a: PredictionResult, b: PredictionResult) => {
            const gradeOrder = { PICK: 0, GOOD: 1, PASS: 2 }
            return gradeOrder[a.prediction.grade] - gradeOrder[b.prediction.grade]
          })
          
          setPredictions(preds)
        }
      } catch (error) {
        console.error('Failed to fetch matches:', error)
        // 에러 시 샘플 데이터 사용
        const filteredSamples = selectedLeague === 'ALL' 
          ? SAMPLE_MATCHES 
          : SAMPLE_MATCHES.filter(m => m.league === selectedLeague)
        
        setMatches(filteredSamples)
        setUsingSampleData(true)
        
        const preds = filteredSamples.map((match: Match) => ({
          match,
          prediction: calculatePrediction(match)
        }))
        
        preds.sort((a: PredictionResult, b: PredictionResult) => {
          const gradeOrder = { PICK: 0, GOOD: 1, PASS: 2 }
          return gradeOrder[a.prediction.grade] - gradeOrder[b.prediction.grade]
        })
        
        setPredictions(preds)
      } finally {
        setLoading(false)
      }
    }
    
    fetchMatches()
  }, [selectedLeague])
  
  // 통계 계산
  const stats = {
    total: predictions.length,
    pick: predictions.filter(p => p.prediction.grade === 'PICK').length,
    good: predictions.filter(p => p.prediction.grade === 'GOOD').length,
    pass: predictions.filter(p => p.prediction.grade === 'PASS').length,
  }

  return (
    <div className="min-h-screen bg-gray-100">
      {/* 히어로 섹션 - 모바일 컴팩트 */}
      <div className="bg-gradient-to-r from-emerald-600 to-green-500 text-white">
        <div className="max-w-7xl mx-auto px-4 py-3">
          <div className="flex items-center justify-between">
            {/* 타이틀 */}
            <div className="flex items-center gap-2">
              <span className="text-xl">⚾</span>
              <div>
                <div className="flex items-center gap-1.5">
                  <h1 className="text-sm font-bold">
                    {language === 'ko' ? 'AI 야구 예측' : 'AI Baseball'}
                  </h1>
                  <span className="px-1 py-0.5 bg-white/20 rounded text-[9px] font-bold">BETA</span>
                </div>
              </div>
            </div>
            
            {/* 통계 - 가로 배치 */}
            <div className="flex items-center gap-1.5">
              <div className="bg-white/10 rounded px-2 py-1 text-center min-w-[36px]">
                <p className="text-sm font-bold">{stats.total}</p>
                <p className="text-[8px] text-white/70">{language === 'ko' ? '경기' : 'G'}</p>
              </div>
              <div className="bg-yellow-400/20 rounded px-2 py-1 text-center min-w-[36px]">
                <p className="text-sm font-bold">{stats.pick}</p>
                <p className="text-[8px] text-yellow-200">PICK</p>
              </div>
              <div className="bg-green-400/20 rounded px-2 py-1 text-center min-w-[36px]">
                <p className="text-sm font-bold">{stats.good}</p>
                <p className="text-[8px] text-green-200">GOOD</p>
              </div>
              <div className="bg-white/10 rounded px-2 py-1 text-center min-w-[36px]">
                <p className="text-sm font-bold">{stats.pass}</p>
                <p className="text-[8px] text-white/70">PASS</p>
              </div>
            </div>
          </div>
        </div>
      </div>
      
      {/* 비시즌 안내 */}
      {usingSampleData && (
        <div className="bg-blue-50 border-b border-blue-100">
          <p className="text-[11px] text-blue-600 text-center py-1.5 px-4">
            ⚠️ {language === 'ko' ? '비시즌 - 샘플 데이터' : 'Off-season - Sample data'}
          </p>
        </div>
      )}
      
      {/* 리그 필터 */}
      <div className="sticky top-0 z-40 bg-white shadow-md">
        <div className="max-w-7xl mx-auto px-4">
          <div className="flex gap-2 py-3 overflow-x-auto scrollbar-hide">
            {LEAGUES.map(league => (
              <button
                key={league.id}
                onClick={() => setSelectedLeague(league.id)}
                className={`
                  px-4 py-2 rounded-full text-sm font-medium whitespace-nowrap transition-all
                  ${selectedLeague === league.id
                    ? 'bg-emerald-500 text-white shadow-md'
                    : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
                  }
                `}
              >
                {language === 'ko' ? league.name : league.nameEn}
              </button>
            ))}
          </div>
        </div>
      </div>
      
      {/* 등급 설명 - 컴팩트 */}
      <div className="max-w-7xl mx-auto px-4 py-2">
        <div className="flex items-center justify-center gap-4 text-[10px]">
          <div className="flex items-center gap-1">
            <GradeBadge grade="PICK" />
            <span className="text-gray-500">20%↑</span>
          </div>
          <div className="flex items-center gap-1">
            <GradeBadge grade="GOOD" />
            <span className="text-gray-500">10~20%</span>
          </div>
          <div className="flex items-center gap-1">
            <GradeBadge grade="PASS" />
            <span className="text-gray-500">10%↓</span>
          </div>
        </div>
      </div>
      
      {/* 예측 카드 목록 */}
      <div className="max-w-7xl mx-auto px-4 pb-24">
        {loading ? (
          <div className="flex flex-col items-center justify-center py-20">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-emerald-500 mb-4"></div>
            <p className="text-gray-500">
              {language === 'ko' ? 'AI가 분석 중입니다...' : 'AI is analyzing...'}
            </p>
          </div>
        ) : predictions.length === 0 ? (
          <div className="text-center py-20">
            <span className="text-6xl mb-4 block">⚾</span>
            <p className="text-gray-500">
              {language === 'ko' ? '예정된 경기가 없습니다' : 'No scheduled matches'}
            </p>
          </div>
        ) : (
          <>
            {/* PICK 경기 */}
            {stats.pick > 0 && (
              <div className="mb-6">
                <h2 className="flex items-center gap-2 text-lg font-bold text-gray-800 mb-3">
                  <span className="text-yellow-500">⭐</span>
                  {language === 'ko' ? 'TOP PICK' : 'TOP PICKS'}
                  <span className="text-sm font-normal text-gray-400">({stats.pick})</span>
                </h2>
                <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {predictions
                    .filter(p => p.prediction.grade === 'PICK')
                    .map(({ match, prediction }) => (
                      <PredictionCard
                        key={match.id}
                        match={match}
                        prediction={prediction}
                        language={language}
                        isSample={usingSampleData}
                      />
                    ))
                  }
                </div>
              </div>
            )}
            
            {/* GOOD 경기 */}
            {stats.good > 0 && (
              <div className="mb-6">
                <h2 className="flex items-center gap-2 text-lg font-bold text-gray-800 mb-3">
                  <span className="text-emerald-500">✓</span>
                  {language === 'ko' ? '추천 경기' : 'Recommended'}
                  <span className="text-sm font-normal text-gray-400">({stats.good})</span>
                </h2>
                <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {predictions
                    .filter(p => p.prediction.grade === 'GOOD')
                    .map(({ match, prediction }) => (
                      <PredictionCard
                        key={match.id}
                        match={match}
                        prediction={prediction}
                        language={language}
                        isSample={usingSampleData}
                      />
                    ))
                  }
                </div>
              </div>
            )}
            
            {/* PASS 경기 */}
            {stats.pass > 0 && (
              <div>
                <h2 className="flex items-center gap-2 text-lg font-bold text-gray-800 mb-3">
                  <span className="text-gray-400">○</span>
                  {language === 'ko' ? '접전 예상' : 'Close Matches'}
                  <span className="text-sm font-normal text-gray-400">({stats.pass})</span>
                </h2>
                <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {predictions
                    .filter(p => p.prediction.grade === 'PASS')
                    .map(({ match, prediction }) => (
                      <PredictionCard
                        key={match.id}
                        match={match}
                        prediction={prediction}
                        language={language}
                        isSample={usingSampleData}
                      />
                    ))
                  }
                </div>
              </div>
            )}
          </>
        )}
      </div>
      
      {/* 면책 조항 */}
      <div className="fixed bottom-16 md:bottom-0 left-0 right-0 bg-gray-900/90 backdrop-blur text-white text-xs text-center py-2 px-4">
        {language === 'ko' 
          ? '⚠️ AI 예측은 참고용이며, 실제 결과와 다를 수 있습니다. 책임감 있는 이용을 권장합니다.'
          : '⚠️ AI predictions are for reference only. Actual results may vary.'}
      </div>
    </div>
  )
}