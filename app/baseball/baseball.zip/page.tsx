'use client'

import { useState, useEffect, useRef } from 'react'
import Link from 'next/link'
import { useLanguage } from '../contexts/LanguageContext'

// =====================================================
// 타입 정의
// =====================================================
interface Match {
  id: number
  league: string
  leagueName: string
  date: string
  time: string
  timestamp: string
  homeTeam: string
  homeTeamKo: string
  homeLogo: string
  homeScore: number | null
  awayTeam: string
  awayTeamKo: string
  awayLogo: string
  awayScore: number | null
  status: string
  innings: {
    home: Record<string, number | null>
    away: Record<string, number | null>
  } | null
  odds: {
    homeWinProb: number
    awayWinProb: number
    homeWinOdds: number
    awayWinOdds: number
    overUnderLine: number
    overOdds: number
    underOdds: number
  } | null
}

interface NewsArticle {
  id: string
  title: string
  description: string
  imageUrl: string
  url: string
  source: string
  publishedAt: string
}

interface NewsCategory {
  id: string
  name: string
  nameKo: string
  nameEn: string
  displayName: string
  logo: string
  hasImage: boolean
  articles: NewsArticle[]
}

// =====================================================
// 상수
// =====================================================
const LEAGUE_COLORS: Record<string, string> = {
  KBO: 'bg-red-500',
  NPB: 'bg-orange-500', 
  MLB: 'bg-blue-600',
  CPBL: 'bg-purple-500',
}

// 팀 로고 컴포넌트
function TeamLogo({ 
  src, 
  team, 
  size = 'md',
  className = ''
}: { 
  src?: string
  team: string
  size?: 'sm' | 'md' | 'lg' | 'xl'
  className?: string
}) {
  const sizeClasses = {
    sm: 'w-6 h-6 text-[10px]',
    md: 'w-10 h-10 text-xs',
    lg: 'w-14 h-14 text-sm',
    xl: 'w-20 h-20 text-base',
  }
  
  if (src) {
    return (
      <img 
        src={src} 
        alt={team} 
        className={`${sizeClasses[size]} object-contain flex-shrink-0 ${className}`}
        onError={(e) => {
          (e.target as HTMLImageElement).style.display = 'none'
        }}
      />
    )
  }
  
  return (
    <div className={`${sizeClasses[size]} rounded-full bg-gray-200 flex items-center justify-center font-bold text-gray-600 flex-shrink-0 border-2 border-gray-300 ${className}`}>
      {team.slice(0, 2)}
    </div>
  )
}

// 시간 포맷 함수
function formatTimeAgo(dateString: string, lang: 'ko' | 'en'): string {
  const now = new Date()
  const date = new Date(dateString)
  const diffMs = now.getTime() - date.getTime()
  const diffHours = Math.floor(diffMs / (1000 * 60 * 60))
  const diffDays = Math.floor(diffHours / 24)
  
  if (diffHours < 1) {
    return lang === 'ko' ? '방금 전' : 'Just now'
  } else if (diffHours < 24) {
    return lang === 'ko' ? `${diffHours}시간 전` : `${diffHours}h ago`
  } else if (diffDays < 7) {
    return lang === 'ko' ? `${diffDays}일 전` : `${diffDays}d ago`
  } else {
    return date.toLocaleDateString(lang === 'ko' ? 'ko-KR' : 'en-US', { month: 'short', day: 'numeric' })
  }
}

// =====================================================
// 순위 타입
// =====================================================
interface StandingTeam {
  rank: number
  team: string
  teamEn: string
  logo: string
  teamId: number
  wins: number
  losses: number
  pct: string
  gb: string
}

// =====================================================
// 메인 컴포넌트
// =====================================================
export default function BaseballMainPage() {
  const { language } = useLanguage()  // 글로벌 언어 상태 사용
  const [newsLeague, setNewsLeague] = useState('ALL')
  const [standingsLeague, setStandingsLeague] = useState('KBO')
  const [standingsSubLeague, setStandingsSubLeague] = useState('ALL')
  const [standings, setStandings] = useState<StandingTeam[]>([])
  const [standingsLoading, setStandingsLoading] = useState(true)
  const [scheduleLeague, setScheduleLeague] = useState('ALL')
  const [matches, setMatches] = useState<Match[]>([])
  const [loading, setLoading] = useState(true)
  const [newsCategories, setNewsCategories] = useState<NewsCategory[]>([])
  const [newsLoading, setNewsLoading] = useState(true)
  const tickerRef = useRef<HTMLDivElement>(null)

  // API에서 순위 데이터 가져오기
  useEffect(() => {
    async function fetchStandings() {
      setStandingsLoading(true)
      try {
        const sub = standingsLeague === 'NPB' 
          ? (standingsSubLeague === 'PACIFIC' ? 'PACIFIC' : 'CENTRAL')
          : standingsLeague === 'MLB'
          ? (standingsSubLeague === 'NL' ? 'NL' : 'AL')
          : 'ALL'
        
        const response = await fetch(`/api/baseball/standings?league=${standingsLeague}&sub=${sub}`)
        const data = await response.json()
        
        if (data.success && data.standings) {
          setStandings(data.standings)
        }
      } catch (err) {
        console.error('Failed to fetch standings:', err)
      } finally {
        setStandingsLoading(false)
      }
    }
    
    fetchStandings()
  }, [standingsLeague, standingsSubLeague])

  // API에서 경기 데이터 가져오기
  useEffect(() => {
    async function fetchMatches() {
      setLoading(true)
      try {
        const response = await fetch('/api/baseball/matches?limit=50')
        const data = await response.json()
        
        if (data.success) {
          setMatches(data.matches)
        }
      } catch (err) {
        console.error('Failed to fetch matches:', err)
      } finally {
        setLoading(false)
      }
    }
    
    fetchMatches()
  }, [])

  // API에서 뉴스 데이터 가져오기
  useEffect(() => {
    async function fetchNews() {
      setNewsLoading(true)
      try {
        const url = `/api/baseball/news?ui=${language}`
        const response = await fetch(url)
        const data = await response.json()
        
        if (data.success && data.categories) {
          setNewsCategories(data.categories)
        }
      } catch (err) {
        console.error('Failed to fetch news:', err)
      } finally {
        setNewsLoading(false)
      }
    }
    
    fetchNews()
  }, [language])

  // 필터링된 뉴스 기사들
  const filteredNewsArticles = newsLeague === 'ALL'
    ? newsCategories.flatMap(cat => cat.articles).slice(0, 6)
    : newsCategories
        .filter(cat => cat.name.toUpperCase().includes(newsLeague))
        .flatMap(cat => cat.articles)
        .slice(0, 6)

  // 피처드 뉴스 (이미지 있는 것 우선)
  const featuredNews = filteredNewsArticles.filter(a => a.imageUrl).slice(0, 2)
  const listNews = filteredNewsArticles.filter(a => !featuredNews.includes(a)).slice(0, 4)

  // TOP PICKS 선정 (확률 차이 큰 상위 5개 경기)
  // TOP PICKS - 확률 차이 큰 상위 경기들
  const topPicks = matches.length > 0 
    ? [...matches]
        .filter(m => m.odds)
        .sort((a, b) => {
          const diffA = Math.abs((a.odds?.homeWinProb || 50) - (a.odds?.awayWinProb || 50))
          const diffB = Math.abs((b.odds?.homeWinProb || 50) - (b.odds?.awayWinProb || 50))
          return diffB - diffA
        })
        .slice(0, 5)
    : []

  // 예정된 경기 (프리뷰용)
  const upcomingPicks = matches
    .filter(m => m.odds && m.status !== 'FT')
    .sort((a, b) => {
      const diffA = Math.abs((a.odds?.homeWinProb || 50) - (a.odds?.awayWinProb || 50))
      const diffB = Math.abs((b.odds?.homeWinProb || 50) - (b.odds?.awayWinProb || 50))
      return diffB - diffA
    })
    .slice(0, 5)

  // 종료된 경기 (결과용)
  const finishedPicks = matches
    .filter(m => m.odds && m.status === 'FT')
    .sort((a, b) => new Date(b.date || '').getTime() - new Date(a.date || '').getTime())
    .slice(0, 5)

  // 적중률 계산
  const predictionResults = finishedPicks.map(match => {
    const predictedHome = (match.odds?.homeWinProb || 0) > (match.odds?.awayWinProb || 0)
    const actualHome = (match.homeScore ?? 0) > (match.awayScore ?? 0)
    const isDraw = (match.homeScore ?? 0) === (match.awayScore ?? 0)
    return {
      match,
      correct: !isDraw && predictedHome === actualHome,
      isDraw,
    }
  })
  
  const correctCount = predictionResults.filter(r => r.correct).length
  const totalCount = predictionResults.filter(r => !r.isDraw).length
  const accuracyRate = totalCount > 0 ? Math.round((correctCount / totalCount) * 100) : 0

  return (
    <div className="min-h-screen bg-gray-200">
      
      {/* ===== 라이브 스코어 ===== */}
      <div className="bg-white border-b border-gray-300 shadow-md">
        <div className="max-w-7xl mx-auto flex items-center">
          {/* LIVE SCORE 라벨 */}
          <div className="flex-shrink-0 flex items-center gap-2 px-4 py-3 border-r border-gray-200 bg-gray-50">
            <span className="relative flex h-2.5 w-2.5">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-red-400 opacity-75"></span>
              <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-red-500"></span>
            </span>
            <span className="text-xs font-bold text-gray-700 whitespace-nowrap">LIVE SCORE</span>
          </div>
          
          {/* 왼쪽 화살표 */}
          <button
            onClick={() => {
              if (tickerRef.current) {
                tickerRef.current.scrollBy({ left: -220, behavior: 'smooth' })
              }
            }}
            className="flex-shrink-0 p-2 hover:bg-gray-100 transition-colors text-gray-400 hover:text-gray-600"
          >
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
            </svg>
          </button>
          
          <div 
            ref={tickerRef}
            className="flex-1 flex overflow-x-auto scrollbar-hide"
          >
            {loading ? (
              <div className="flex items-center justify-center w-full py-4">
                <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-emerald-500"></div>
              </div>
            ) : matches.length === 0 ? (
              <div className="flex items-center justify-center w-full py-4 text-gray-500 text-sm">
                {language === 'ko' ? '📅 오늘 예정된 경기가 없습니다' : '📅 No games scheduled today'}
              </div>
            ) : (
              matches.slice(0, 10).map((match) => (
                <Link
                  key={match.id}
                  href={`/baseball/${match.id}`}
                  className="flex-shrink-0 flex items-center gap-3 px-5 py-3 border-r border-gray-200 hover:bg-gray-50 transition-colors min-w-[220px]"
                >
                  {/* 리그 뱃지 */}
                  <span className={`text-[10px] font-bold text-white px-2 py-0.5 rounded shadow-sm ${LEAGUE_COLORS[match.league]}`}>
                    {match.league}
                  </span>
                  
                  {/* 팀 & 스코어 */}
                  <div className="flex-1 space-y-1">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <TeamLogo src={match.awayLogo} team={match.awayTeamKo} size="sm" />
                        <span className={`text-sm ${match.status === 'FT' && (match.awayScore ?? 0) > (match.homeScore ?? 0) ? 'font-bold text-gray-900' : 'text-gray-600'}`}>
                          {language === 'ko' ? match.awayTeamKo : match.awayTeam}
                        </span>
                      </div>
                      <span className={`font-mono font-bold text-sm ${match.status === 'FT' && (match.awayScore ?? 0) > (match.homeScore ?? 0) ? 'text-gray-900' : 'text-gray-400'}`}>
                        {match.awayScore ?? '-'}
                      </span>
                    </div>
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <TeamLogo src={match.homeLogo} team={match.homeTeamKo} size="sm" />
                        <span className={`text-sm ${match.status === 'FT' && (match.homeScore ?? 0) > (match.awayScore ?? 0) ? 'font-bold text-gray-900' : 'text-gray-600'}`}>
                          {language === 'ko' ? match.homeTeamKo : match.homeTeam}
                        </span>
                      </div>
                      <span className={`font-mono font-bold text-sm ${match.status === 'FT' && (match.homeScore ?? 0) > (match.awayScore ?? 0) ? 'text-gray-900' : 'text-gray-400'}`}>
                        {match.homeScore ?? '-'}
                      </span>
                    </div>
                  </div>
                  
                  {/* 상태 */}
                  <div className="text-right w-12">
                    {match.status === 'FT' ? (
                      <span className="text-xs text-gray-500 font-medium">Final</span>
                    ) : (
                      <span className="text-xs text-gray-500">{match.time?.slice(0, 5)}</span>
                    )}
                  </div>
                </Link>
              ))
            )}
          </div>
          
          {/* 오른쪽 화살표 */}
          <button
            onClick={() => {
              if (tickerRef.current) {
                tickerRef.current.scrollBy({ left: 220, behavior: 'smooth' })
              }
            }}
            className="flex-shrink-0 p-2 hover:bg-gray-100 transition-colors text-gray-400 hover:text-gray-600"
          >
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
            </svg>
          </button>
        </div>
      </div>

      {/* ===== 메인 컨텐츠 ===== */}
      <main className="max-w-7xl mx-auto px-4 py-6">
        
        {/* 상단: 추천 경기 + 사이드바 */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
          
          {/* 추천 경기 3개 - 2컬럼 */}
          <div className="lg:col-span-2">
            <div className="flex items-center gap-2 mb-4">
              <span className="text-lg">🔥</span>
              <h2 className="text-lg font-bold text-gray-800">
                {language === 'ko' ? '추천 경기' : 'Top Picks'}
              </h2>
              <span className="text-xs text-gray-500 bg-gray-100 px-2 py-1 rounded-full">
                {language === 'ko' ? 'AI 예측 기반' : 'AI Predicted'}
              </span>
            </div>
            
            {topPicks.length > 0 ? (
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                {topPicks.slice(0, 3).map((match, index) => (
                  <Link 
                    key={match.id}
                    href={`/baseball/${match.id}`}
                    className="block relative overflow-hidden rounded-xl bg-white shadow-lg hover:shadow-xl transition-all group border border-gray-200 hover:border-emerald-300"
                  >
                    {/* 리그 컬러 바 */}
                    <div className={`h-1 ${LEAGUE_COLORS[match.league]}`} />
                    
                    <div className="p-4">
                      {/* 상단: 뱃지 + 시간 */}
                      <div className="flex items-center justify-between mb-3">
                        <div className="flex items-center gap-2">
                          {index === 0 && (
                            <span className="px-2 py-0.5 rounded-full bg-amber-400 text-amber-900 text-[10px] font-bold">
                              BEST
                            </span>
                          )}
                          <span className={`text-[10px] font-bold text-white px-1.5 py-0.5 rounded ${LEAGUE_COLORS[match.league]}`}>
                            {match.league}
                          </span>
                        </div>
                        <span className="text-[10px] text-gray-400">
                          {match.date?.slice(5)} {match.time?.slice(0, 5)}
                        </span>
                      </div>
                      
                      {/* 팀 매치업 */}
                      <div className="space-y-2 mb-3">
                        {/* 홈팀 */}
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-2">
                            <TeamLogo src={match.homeLogo} team={match.homeTeamKo} size="sm" />
                            <span className={`text-sm font-medium truncate max-w-[80px] ${
                              match.status === 'FT' && (match.homeScore ?? 0) > (match.awayScore ?? 0) 
                                ? 'text-gray-900 font-bold' : 'text-gray-700'
                            }`}>
                              {language === 'ko' ? match.homeTeamKo : match.homeTeam}
                            </span>
                          </div>
                          <div className="flex items-center gap-2">
                            {match.odds && (
                              <span className={`text-xs font-bold ${
                                match.odds.homeWinProb > match.odds.awayWinProb ? 'text-emerald-600' : 'text-gray-400'
                              }`}>
                                {match.odds.homeWinProb}%
                              </span>
                            )}
                            {match.status === 'FT' && (
                              <span className="text-sm font-bold text-gray-800 w-4 text-right">
                                {match.homeScore}
                              </span>
                            )}
                          </div>
                        </div>
                        
                        {/* 원정팀 */}
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-2">
                            <TeamLogo src={match.awayLogo} team={match.awayTeamKo} size="sm" />
                            <span className={`text-sm font-medium truncate max-w-[80px] ${
                              match.status === 'FT' && (match.awayScore ?? 0) > (match.homeScore ?? 0) 
                                ? 'text-gray-900 font-bold' : 'text-gray-700'
                            }`}>
                              {language === 'ko' ? match.awayTeamKo : match.awayTeam}
                            </span>
                          </div>
                          <div className="flex items-center gap-2">
                            {match.odds && (
                              <span className={`text-xs font-bold ${
                                match.odds.awayWinProb > match.odds.homeWinProb ? 'text-emerald-600' : 'text-gray-400'
                              }`}>
                                {match.odds.awayWinProb}%
                              </span>
                            )}
                            {match.status === 'FT' && (
                              <span className="text-sm font-bold text-gray-800 w-4 text-right">
                                {match.awayScore}
                              </span>
                            )}
                          </div>
                        </div>
                      </div>
                      
                      {/* 확률 바 */}
                      {match.odds && (
                        <div className="h-1.5 rounded-full overflow-hidden bg-gray-200 flex">
                          <div 
                            className={`transition-all ${match.odds.homeWinProb > match.odds.awayWinProb ? 'bg-emerald-500' : 'bg-gray-300'}`}
                            style={{ width: `${match.odds.homeWinProb}%` }}
                          />
                          <div 
                            className={`transition-all ${match.odds.awayWinProb > match.odds.homeWinProb ? 'bg-emerald-500' : 'bg-gray-300'}`}
                            style={{ width: `${match.odds.awayWinProb}%` }}
                          />
                        </div>
                      )}
                    </div>
                  </Link>
                ))}
              </div>
            ) : (
              <div className="grid grid-cols-3 gap-4">
                {[1, 2, 3].map((i) => (
                  <div key={i} className="rounded-xl bg-white shadow-lg border border-gray-200 p-4 animate-pulse">
                    <div className="h-4 bg-gray-200 rounded w-1/2 mb-3"></div>
                    <div className="h-6 bg-gray-200 rounded mb-2"></div>
                    <div className="h-6 bg-gray-200 rounded mb-3"></div>
                    <div className="h-1.5 bg-gray-200 rounded"></div>
                  </div>
                ))}
              </div>
            )}
            
            {/* 오늘의 AI 픽 (프리뷰) */}
            {upcomingPicks.length > 0 && (
              <div className="mt-4 bg-white rounded-xl shadow-lg border border-gray-200 overflow-hidden">
                <div className="px-4 py-2.5 bg-gradient-to-r from-emerald-500 to-teal-500 flex items-center gap-2">
                  <span className="text-sm">🔮</span>
                  <h3 className="text-sm font-bold text-white">
                    {language === 'ko' ? '오늘의 AI 픽' : "Today's AI Picks"}
                  </h3>
                  <span className="ml-auto text-xs text-emerald-100">
                    {upcomingPicks.length}{language === 'ko' ? '경기' : ' games'}
                  </span>
                </div>
                <div className="divide-y divide-gray-100">
                  {upcomingPicks.map((match) => {
                    const homeWin = match.odds && match.odds.homeWinProb > match.odds.awayWinProb
                    const winTeam = homeWin 
                      ? (language === 'ko' ? match.homeTeamKo : match.homeTeam)
                      : (language === 'ko' ? match.awayTeamKo : match.awayTeam)
                    const winProb = homeWin ? match.odds?.homeWinProb : match.odds?.awayWinProb
                    
                    return (
                      <Link
                        key={match.id}
                        href={`/baseball/${match.id}`}
                        className="block px-4 py-3 hover:bg-emerald-50 transition-colors group"
                      >
                        <div className="flex items-start gap-3">
                          <span className="flex-shrink-0 text-lg">🎯</span>
                          <div className="flex-1 min-w-0">
                            <div className="flex items-center gap-2 mb-1">
                              <span className="text-sm font-bold text-gray-800">
                                {language === 'ko' ? match.homeTeamKo : match.homeTeam} vs {language === 'ko' ? match.awayTeamKo : match.awayTeam}
                              </span>
                              <span className={`text-[10px] font-bold text-white px-1.5 py-0.5 rounded ${LEAGUE_COLORS[match.league]}`}>
                                {match.league}
                              </span>
                            </div>
                            <p className="text-sm text-gray-600">
                              {language === 'ko' ? (
                                <>
                                  AI 예측: <span className="font-bold text-emerald-600">{winTeam}</span> 
                                  <span className="font-bold text-emerald-600"> {winProb}%</span> 우세
                                  <span className="text-gray-400 ml-2">
                                    ({match.date?.slice(5)} {match.time?.slice(0, 5)})
                                  </span>
                                </>
                              ) : (
                                <>
                                  AI predicts: <span className="font-bold text-emerald-600">{winTeam}</span> 
                                  <span className="font-bold text-emerald-600"> {winProb}%</span>
                                  <span className="text-gray-400 ml-2">
                                    ({match.date?.slice(5)} {match.time?.slice(0, 5)})
                                  </span>
                                </>
                              )}
                            </p>
                          </div>
                          <span className="text-gray-300 group-hover:text-emerald-500 transition-colors">→</span>
                        </div>
                      </Link>
                    )
                  })}
                </div>
              </div>
            )}

            {/* 최근 결과 - 개선된 버전 */}
            {finishedPicks.length > 0 && (
              <div className="mt-4 bg-white rounded-xl shadow-lg border border-gray-200 overflow-hidden">
                <div className="px-4 py-2.5 bg-gray-800 flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span className="text-sm">📊</span>
                    <h3 className="text-sm font-bold text-white">
                      {language === 'ko' ? '최근 결과' : 'Recent Results'}
                    </h3>
                  </div>
                  {totalCount > 0 && (
                    <span className="text-xs px-2 py-0.5 rounded-full bg-emerald-500 text-white font-bold">
                      {accuracyRate}% ({correctCount}/{totalCount})
                    </span>
                  )}
                </div>
                
                {/* 테이블 형식 */}
                <div className="divide-y divide-gray-100">
                  {predictionResults.map(({ match, correct, isDraw }) => {
                    const homeWin = (match.homeScore ?? 0) > (match.awayScore ?? 0)
                    
                    return (
                      <Link
                        key={match.id}
                        href={`/baseball/${match.id}`}
                        className="flex items-center px-3 py-2.5 hover:bg-gray-50 transition-colors gap-2"
                      >
                        {/* 적중 여부 */}
                        <div className={`w-6 h-6 rounded-full flex items-center justify-center flex-shrink-0 ${
                          isDraw ? 'bg-gray-100' : correct ? 'bg-emerald-100' : 'bg-red-100'
                        }`}>
                          <span className={`text-xs font-bold ${
                            isDraw ? 'text-gray-500' : correct ? 'text-emerald-600' : 'text-red-500'
                          }`}>
                            {isDraw ? '-' : correct ? '✓' : '✗'}
                          </span>
                        </div>
                        
                        {/* 원정팀 */}
                        <div className="flex items-center gap-1.5 flex-1 min-w-0">
                          <TeamLogo src={match.awayLogo} team={match.awayTeamKo} size="sm" />
                          <span className={`text-xs truncate ${!homeWin && !isDraw ? 'font-bold text-gray-900' : 'text-gray-500'}`}>
                            {language === 'ko' ? match.awayTeamKo : match.awayTeam}
                          </span>
                        </div>
                        
                        {/* 스코어 */}
                        <div className="flex items-center gap-1.5 px-2">
                          <span className={`text-sm font-bold ${!homeWin && !isDraw ? 'text-gray-900' : 'text-gray-400'}`}>
                            {match.awayScore}
                          </span>
                          <span className="text-gray-300 text-xs">-</span>
                          <span className={`text-sm font-bold ${homeWin ? 'text-gray-900' : 'text-gray-400'}`}>
                            {match.homeScore}
                          </span>
                        </div>
                        
                        {/* 홈팀 */}
                        <div className="flex items-center gap-1.5 flex-1 min-w-0 justify-end">
                          <span className={`text-xs truncate ${homeWin ? 'font-bold text-gray-900' : 'text-gray-500'}`}>
                            {language === 'ko' ? match.homeTeamKo : match.homeTeam}
                          </span>
                          <TeamLogo src={match.homeLogo} team={match.homeTeamKo} size="sm" />
                        </div>
                        
                        {/* 리그 */}
                        <span className={`text-[9px] font-bold text-white px-1.5 py-0.5 rounded flex-shrink-0 ${LEAGUE_COLORS[match.league]}`}>
                          {match.league}
                        </span>
                      </Link>
                    )
                  })}
                </div>
              </div>
            )}
          </div>
          
          {/* 사이드바: 순위 */}
          <div className="lg:col-span-1">
            <div className="rounded-xl bg-white shadow-xl overflow-hidden h-full border border-gray-300 flex flex-col">
              {/* 헤더 */}
              <div className="flex items-center justify-between px-4 py-3 bg-gray-100 border-b border-gray-200">
                <h3 className="font-bold text-gray-800 text-sm flex items-center gap-2">
                  📊 {language === 'ko' ? '순위' : 'Standings'}
                </h3>
                <select
                  value={standingsLeague}
                  onChange={(e) => {
                    setStandingsLeague(e.target.value)
                    // 리그 변경 시 서브리그 초기화
                    if (e.target.value === 'NPB') setStandingsSubLeague('CENTRAL')
                    else if (e.target.value === 'MLB') setStandingsSubLeague('AL')
                    else setStandingsSubLeague('ALL')
                  }}
                  className="text-xs bg-white border border-gray-300 rounded-lg px-2 py-1.5 text-gray-600 font-medium focus:outline-none focus:ring-2 focus:ring-emerald-500"
                >
                  <option value="KBO">KBO</option>
                  <option value="NPB">NPB</option>
                  <option value="MLB">MLB</option>
                  <option value="CPBL">CPBL</option>
                </select>
              </div>
              
              {/* 서브 리그 탭 (NPB, MLB만) */}
              {(standingsLeague === 'NPB' || standingsLeague === 'MLB') && (
                <div className="flex px-3 py-2 bg-gray-50 border-b border-gray-100 gap-1">
                  {standingsLeague === 'NPB' ? (
                    <>
                      <button
                        onClick={() => setStandingsSubLeague('CENTRAL')}
                        className={`flex-1 px-2 py-1.5 rounded-md text-xs font-bold transition-all ${
                          standingsSubLeague === 'CENTRAL'
                            ? 'bg-emerald-500 text-white shadow-sm'
                            : 'bg-white text-gray-500 hover:text-gray-700 border border-gray-200'
                        }`}
                      >
                        {language === 'ko' ? '센트럴' : 'Central'}
                      </button>
                      <button
                        onClick={() => setStandingsSubLeague('PACIFIC')}
                        className={`flex-1 px-2 py-1.5 rounded-md text-xs font-bold transition-all ${
                          standingsSubLeague === 'PACIFIC'
                            ? 'bg-emerald-500 text-white shadow-sm'
                            : 'bg-white text-gray-500 hover:text-gray-700 border border-gray-200'
                        }`}
                      >
                        {language === 'ko' ? '퍼시픽' : 'Pacific'}
                      </button>
                    </>
                  ) : (
                    <>
                      <button
                        onClick={() => setStandingsSubLeague('AL')}
                        className={`flex-1 px-2 py-1.5 rounded-md text-xs font-bold transition-all ${
                          standingsSubLeague === 'AL'
                            ? 'bg-emerald-500 text-white shadow-sm'
                            : 'bg-white text-gray-500 hover:text-gray-700 border border-gray-200'
                        }`}
                      >
                        AL
                      </button>
                      <button
                        onClick={() => setStandingsSubLeague('NL')}
                        className={`flex-1 px-2 py-1.5 rounded-md text-xs font-bold transition-all ${
                          standingsSubLeague === 'NL'
                            ? 'bg-emerald-500 text-white shadow-sm'
                            : 'bg-white text-gray-500 hover:text-gray-700 border border-gray-200'
                        }`}
                      >
                        NL
                      </button>
                    </>
                  )}
                </div>
              )}
              
              {/* 테이블 헤더 */}
              <div className="flex items-center px-4 py-2 bg-gray-50 border-b border-gray-100 text-xs text-gray-500 font-medium">
                <span className="w-8">#</span>
                <span className="flex-1">{language === 'ko' ? '팀' : 'Team'}</span>
                <span className="w-14 text-center">{language === 'ko' ? '승-패' : 'W-L'}</span>
                <span className="w-12 text-right">{language === 'ko' ? '승률' : 'PCT'}</span>
              </div>
              
              {/* 순위 목록 */}
              <div className="divide-y divide-gray-100 flex-1">
                {standingsLoading ? (
                  <div className="flex items-center justify-center py-8">
                    <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-emerald-500"></div>
                  </div>
                ) : standings.length === 0 ? (
                  <div className="flex items-center justify-center py-8 text-gray-500 text-sm">
                    {language === 'ko' ? '순위 정보가 없습니다' : 'No standings data'}
                  </div>
                ) : (
                  standings.map((team) => (
                    <div key={team.rank} className="flex items-center px-4 py-2.5 hover:bg-gray-50 transition-colors">
                      {/* 순위 뱃지 */}
                      <div className="w-8">
                        {team.rank === 1 ? (
                          <span className="inline-flex items-center justify-center w-6 h-6 rounded-full bg-amber-400 text-white text-xs font-bold">1</span>
                        ) : team.rank === 2 ? (
                          <span className="inline-flex items-center justify-center w-6 h-6 rounded-full bg-gray-400 text-white text-xs font-bold">2</span>
                        ) : team.rank === 3 ? (
                          <span className="inline-flex items-center justify-center w-6 h-6 rounded-full bg-amber-600 text-white text-xs font-bold">3</span>
                        ) : (
                          <span className="inline-flex items-center justify-center w-6 h-6 text-gray-400 text-sm font-medium">{team.rank}</span>
                        )}
                      </div>
                      
                      {/* 팀 로고 + 이름 */}
                      <div className="flex items-center gap-2 flex-1 min-w-0">
                        <TeamLogo src={team.logo} team={team.team} size="sm" />
                        <span className={`text-sm font-semibold truncate ${team.rank <= 3 ? 'text-gray-900' : 'text-gray-600'}`}>
                          {language === 'ko' ? team.team : team.teamEn}
                        </span>
                      </div>
                      
                      {/* 승-패 */}
                      <span className="w-14 text-center text-xs text-gray-500 tabular-nums">
                        {team.wins}-{team.losses}
                      </span>
                      
                      {/* 승률 */}
                      <span className={`w-12 text-right text-sm font-bold tabular-nums ${
                        team.rank === 1 ? 'text-emerald-600' : 'text-gray-700'
                      }`}>
                        {team.pct}
                      </span>
                    </div>
                  ))
                )}
              </div>
              
              {/* 더보기 */}
              <Link 
                href="/baseball/standings"
                className="block px-4 py-2.5 text-center text-sm text-emerald-600 hover:text-emerald-700 border-t border-gray-100 transition-colors font-medium hover:bg-emerald-50 mt-auto"
              >
                {language === 'ko' ? '전체 순위 보기' : 'View Full Standings'} →
              </Link>
            </div>
          </div>
        </div>

        {/* ===== 경기 스케줄 ===== */}
        <section className="mb-8">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-lg font-bold text-gray-800 flex items-center gap-2">
              📅 {language === 'ko' ? '경기 스케줄' : 'Game Schedule'}
            </h2>
            <div className="flex gap-1 bg-gray-100 rounded-lg p-1 border border-gray-300">
              {['ALL', 'KBO', 'NPB', 'MLB', 'CPBL'].map((league) => (
                <button
                  key={league}
                  onClick={() => setScheduleLeague(league)}
                  className={`px-3 py-1.5 rounded-md text-xs font-bold transition-all ${
                    scheduleLeague === league
                      ? 'bg-white text-gray-800 shadow-md border border-gray-200'
                      : 'text-gray-500 hover:text-gray-700'
                  }`}
                >
                  {league === 'ALL' ? (language === 'ko' ? '전체' : 'All') : league}
                </button>
              ))}
            </div>
          </div>
          
          {loading ? (
            <div className="flex items-center justify-center py-12">
              <div className="animate-spin rounded-full h-10 w-10 border-b-2 border-emerald-500"></div>
            </div>
          ) : (
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-4">
              {matches
                .filter(m => scheduleLeague === 'ALL' || m.league === scheduleLeague)
                .slice(0, 10)
                .map((match) => (
                  <Link
                    key={match.id}
                    href={`/baseball/${match.id}`}
                    className="bg-white rounded-xl shadow-lg hover:shadow-xl transition-all overflow-hidden border border-gray-200 hover:border-emerald-300 group"
                  >
                    {/* 리그 컬러 바 */}
                    <div className={`h-1 ${LEAGUE_COLORS[match.league]}`} />
                    
                    {/* 헤더 */}
                    <div className="flex items-center justify-between px-3 py-2 bg-gray-50 border-b border-gray-100">
                      <span className={`text-[10px] font-bold text-white px-1.5 py-0.5 rounded ${LEAGUE_COLORS[match.league]}`}>
                        {match.league}
                      </span>
                      <span className="text-[10px] text-gray-500">
                        {match.date?.slice(5)} {match.time?.slice(0, 5)}
                      </span>
                    </div>
                    
                    {/* 팀 정보 */}
                    <div className="p-3">
                      {/* 홈팀 */}
                      <div className="flex items-center justify-between mb-2">
                        <div className="flex items-center gap-2 flex-1 min-w-0">
                          <TeamLogo src={match.homeLogo} team={match.homeTeamKo} size="sm" />
                          <span className={`text-xs font-medium truncate ${
                            match.status === 'FT' && (match.homeScore ?? 0) > (match.awayScore ?? 0)
                              ? 'text-emerald-600 font-bold' : 'text-gray-700'
                          }`}>
                            {language === 'ko' ? match.homeTeamKo : match.homeTeam}
                          </span>
                        </div>
                        {match.status === 'FT' ? (
                          <span className={`text-sm font-bold ${
                            (match.homeScore ?? 0) > (match.awayScore ?? 0) ? 'text-emerald-600' : 'text-gray-400'
                          }`}>{match.homeScore}</span>
                        ) : match.odds && (
                          <span className={`text-[10px] font-bold ${
                            match.odds.homeWinProb > match.odds.awayWinProb ? 'text-emerald-600' : 'text-gray-400'
                          }`}>{match.odds.homeWinProb}%</span>
                        )}
                      </div>
                      
                      {/* 원정팀 */}
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2 flex-1 min-w-0">
                          <TeamLogo src={match.awayLogo} team={match.awayTeamKo} size="sm" />
                          <span className={`text-xs font-medium truncate ${
                            match.status === 'FT' && (match.awayScore ?? 0) > (match.homeScore ?? 0)
                              ? 'text-emerald-600 font-bold' : 'text-gray-700'
                          }`}>
                            {language === 'ko' ? match.awayTeamKo : match.awayTeam}
                          </span>
                        </div>
                        {match.status === 'FT' ? (
                          <span className={`text-sm font-bold ${
                            (match.awayScore ?? 0) > (match.homeScore ?? 0) ? 'text-emerald-600' : 'text-gray-400'
                          }`}>{match.awayScore}</span>
                        ) : match.odds && (
                          <span className={`text-[10px] font-bold ${
                            match.odds.awayWinProb > match.odds.homeWinProb ? 'text-emerald-600' : 'text-gray-400'
                          }`}>{match.odds.awayWinProb}%</span>
                        )}
                      </div>
                      
                      {/* 상태 */}
                      <div className="mt-2 pt-2 border-t border-gray-100 text-center">
                        {match.status === 'FT' ? (
                          <span className="text-[10px] text-gray-400 font-medium">Final</span>
                        ) : (
                          <span className="text-[10px] text-emerald-600 font-medium">
                            {language === 'ko' ? '예정' : 'Scheduled'}
                          </span>
                        )}
                      </div>
                    </div>
                  </Link>
                ))}
            </div>
          )}
          
          {/* 더보기 */}
          {matches.filter(m => scheduleLeague === 'ALL' || m.league === scheduleLeague).length > 10 && (
            <div className="mt-4 text-center">
              <Link 
                href="/baseball/results"
                className="inline-flex items-center gap-2 px-4 py-2 bg-gray-100 hover:bg-gray-200 rounded-lg text-sm text-gray-600 font-medium transition-colors"
              >
                {language === 'ko' ? '전체 일정 보기' : 'View All Schedule'} →
              </Link>
            </div>
          )}
        </section>

        {/* ===== 뉴스 섹션 ===== */}
        <section className="mb-8">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-lg font-bold text-gray-800 flex items-center gap-2">
              📰 {language === 'ko' ? '야구 뉴스' : 'Baseball News'}
            </h2>
            
            {/* 리그 필터 */}
            <div className="flex gap-1 bg-gray-100 rounded-lg p-1 border border-gray-300">
              {['ALL', 'KBO', 'MLB', 'NPB'].map((league) => (
                <button
                  key={league}
                  onClick={() => setNewsLeague(league)}
                  className={`px-3 py-1.5 rounded-md text-xs font-bold transition-all ${
                    newsLeague === league
                      ? 'bg-white text-gray-800 shadow-md border border-gray-200'
                      : 'text-gray-500 hover:text-gray-700'
                  }`}
                >
                  {league === 'ALL' ? (language === 'ko' ? '전체' : 'All') : league}
                </button>
              ))}
            </div>
          </div>
          
          {newsLoading ? (
            <div className="flex items-center justify-center py-12">
              <div className="animate-spin rounded-full h-10 w-10 border-b-2 border-emerald-500"></div>
            </div>
          ) : filteredNewsArticles.length === 0 ? (
            <div className="bg-white rounded-xl shadow-xl border border-gray-300 p-8 text-center">
              <p className="text-gray-500">
                {language === 'ko' ? '뉴스를 불러오는 중입니다...' : 'Loading news...'}
              </p>
            </div>
          ) : (
            <>
              {/* 피처드 뉴스 (이미지 있는 2개) */}
              {featuredNews.length > 0 && (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                  {featuredNews.map((news) => (
                    <a
                      key={news.id}
                      href={news.url}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="group rounded-xl bg-white shadow-xl hover:shadow-2xl transition-all overflow-hidden border border-gray-300"
                    >
                      {/* 이미지 영역 */}
                      <div className="aspect-video bg-gray-100 relative overflow-hidden">
                        {news.imageUrl ? (
                          <img 
                            src={news.imageUrl} 
                            alt={news.title}
                            className="w-full h-full object-cover object-top group-hover:scale-105 transition-transform duration-300"
                            onError={(e) => {
                              (e.target as HTMLImageElement).style.display = 'none'
                            }}
                          />
                        ) : (
                          <div className="w-full h-full flex items-center justify-center bg-gradient-to-br from-emerald-100 to-teal-100">
                            <span className="text-6xl">⚾</span>
                          </div>
                        )}
                      </div>
                      
                      {/* 텍스트 */}
                      <div className="p-4">
                        <div className="flex items-center gap-2 mb-2">
                          <span className="text-xs text-gray-500 font-medium">
                            {news.source}
                          </span>
                          <span className="text-xs text-gray-400">•</span>
                          <span className="text-xs text-gray-500">
                            {formatTimeAgo(news.publishedAt, language)}
                          </span>
                        </div>
                        <h3 className="font-bold text-gray-800 group-hover:text-emerald-600 transition-colors line-clamp-2 mb-2">
                          {news.title}
                        </h3>
                        <p className="text-sm text-gray-500 line-clamp-2">
                          {news.description}
                        </p>
                      </div>
                    </a>
                  ))}
                </div>
              )}
              
              {/* 일반 뉴스 리스트 */}
              {listNews.length > 0 && (
                <div className="rounded-xl bg-white shadow-xl divide-y divide-gray-200 border border-gray-300">
                  {listNews.map((news) => (
                    <a
                      key={news.id}
                      href={news.url}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="flex items-center gap-4 p-4 hover:bg-gray-50 transition-colors group"
                    >
                      {/* 썸네일 */}
                      <div className="w-16 h-16 rounded-lg overflow-hidden flex-shrink-0 bg-gray-100">
                        {news.imageUrl ? (
                          <img 
                            src={news.imageUrl} 
                            alt={news.title}
                            className="w-full h-full object-cover"
                            onError={(e) => {
                              (e.target as HTMLImageElement).style.display = 'none'
                            }}
                          />
                        ) : (
                          <div className="w-full h-full flex items-center justify-center bg-gradient-to-br from-gray-100 to-gray-200">
                            <span className="text-2xl">⚾</span>
                          </div>
                        )}
                      </div>
                      
                      {/* 텍스트 */}
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 mb-1">
                          <span className="text-xs text-gray-500 font-medium">
                            {news.source}
                          </span>
                          <span className="text-xs text-gray-400">•</span>
                          <span className="text-xs text-gray-500">
                            {formatTimeAgo(news.publishedAt, language)}
                          </span>
                        </div>
                        <h3 className="font-bold text-gray-800 group-hover:text-emerald-600 transition-colors line-clamp-2">
                          {news.title}
                        </h3>
                      </div>
                      
                      {/* 화살표 */}
                      <span className="text-gray-300 group-hover:text-emerald-500 transition-colors text-lg flex-shrink-0">→</span>
                    </a>
                  ))}
                </div>
              )}
            </>
          )}
        </section>

      </main>
      
      {/* 하단 여백 (BottomNavigation 공간) */}
      <div className="h-20 md:h-0" />
    </div>
  )
}