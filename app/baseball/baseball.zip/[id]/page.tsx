'use client'

import { useState, useEffect } from 'react'
import Link from 'next/link'
import { useParams } from 'next/navigation'
import { useLanguage } from '../../contexts/LanguageContext'

// =====================================================
// 타입 정의
// =====================================================
interface MatchDetail {
  id: number
  league: string
  leagueName: string
  season: string
  date: string
  time: string
  timestamp: string
  venue: string | null
  home: {
    id: number
    team: string
    teamKo: string
    logo: string
    score: number | null
  }
  away: {
    id: number
    team: string
    teamKo: string
    logo: string
    score: number | null
  }
  status: string
  innings: {
    home: Record<string, number | null>
    away: Record<string, number | null>
  } | null
  odds: {
    homeWinProb: number
    awayWinProb: number
    homeWinOdds: number
    awayWinOdds: number
    overUnderLine: number
    overOdds: number
    underOdds: number
    bookmaker: string
    updatedAt: string
  } | null
  oddsTrend: Array<{
    time: string
    homeProb: number
    awayProb: number
  }>
  h2h: Array<{
    id: number
    date: string
    homeTeam: string
    awayTeam: string
    homeScore: number
    awayScore: number
  }>
  teamStats: {
    home: {
      recentForm: string
      avgRuns: number
      winRate: number
    }
    away: {
      recentForm: string
      avgRuns: number
      winRate: number
    }
  } | null
  relatedMatches: Array<{
    id: number
    homeTeam: string
    awayTeam: string
    homeLogo: string
    awayLogo: string
    date: string
    time: string
    homeScore: number | null
    awayScore: number | null
    status: string
  }>
}

// =====================================================
// 상수
// =====================================================
const LEAGUE_COLORS: Record<string, string> = {
  KBO: 'bg-red-500',
  NPB: 'bg-orange-500', 
  MLB: 'bg-blue-600',
  CPBL: 'bg-purple-500',
}

// =====================================================
// 팀 로고 컴포넌트
// =====================================================
function TeamLogo({ src, team, size = 'md' }: { src?: string; team: string; size?: 'sm' | 'md' | 'lg' }) {
  const sizeClasses = {
    sm: 'w-6 h-6',
    md: 'w-12 h-12',
    lg: 'w-16 h-16',
  }
  
  if (src) {
    return (
      <img 
        src={src} 
        alt={team} 
        className={`${sizeClasses[size]} object-contain`}
        onError={(e) => { (e.target as HTMLImageElement).style.display = 'none' }}
      />
    )
  }
  
  return (
    <div className={`${sizeClasses[size]} rounded-full bg-gray-200 flex items-center justify-center font-bold text-gray-500 text-xs`}>
      {team.slice(0, 2)}
    </div>
  )
}

// =====================================================
// 메인 컴포넌트
// =====================================================
export default function BaseballDetailPage() {
  const params = useParams()
  const matchId = params?.id as string
  const { language } = useLanguage()
  
  const [match, setMatch] = useState<MatchDetail | null>(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    async function fetchMatch() {
      if (!matchId) return
      setLoading(true)
      setError(null)
      
      try {
        const response = await fetch(`/api/baseball/matches/${matchId}`)
        const data = await response.json()
        
        if (data.success) {
          setMatch(data.match)
        } else {
          setError(data.error || '경기 정보를 불러오는데 실패했습니다.')
        }
      } catch (err: any) {
        setError(err.message || '서버 연결에 실패했습니다.')
      } finally {
        setLoading(false)
      }
    }
    
    fetchMatch()
  }, [matchId])

  const isFinished = match?.status === 'FT'

  // 이닝 스코어 배열
  const getInningsArray = () => {
    if (!match?.innings) return []
    const innings = []
    for (let i = 1; i <= 9; i++) {
      innings.push({
        inning: i,
        away: match.innings.away?.[i.toString()] ?? '-',
        home: match.innings.home?.[i.toString()] ?? '-',
      })
    }
    return innings
  }

  // 로딩
  if (loading) {
    return (
      <div className="min-h-screen bg-gray-100 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-10 w-10 border-b-2 border-gray-500 mx-auto mb-3"></div>
          <p className="text-gray-500 text-sm">로딩 중...</p>
        </div>
      </div>
    )
  }

  // 에러
  if (error || !match) {
    return (
      <div className="min-h-screen bg-gray-100 flex items-center justify-center p-4">
        <div className="bg-white rounded-lg shadow p-6 text-center max-w-sm w-full">
          <div className="text-4xl mb-3">⚾</div>
          <h1 className="text-base font-bold text-gray-800 mb-2">경기를 찾을 수 없습니다</h1>
          <p className="text-red-500 text-sm mb-4">{error}</p>
          <Link href="/baseball" className="inline-block px-4 py-2 bg-gray-800 text-white rounded text-sm">
            돌아가기
          </Link>
        </div>
      </div>
    )
  }

  const innings = getInningsArray()

  return (
    <div className="min-h-screen bg-gray-100 pb-20">
      {/* 메인 스코어 카드 */}
      <div className="bg-white border-b">
        {/* 리그 + 상태 */}
        <div className="flex items-center justify-between px-4 py-2 bg-gray-50 border-b">
          <div className="flex items-center gap-2">
            <span className={`px-1.5 py-0.5 text-[10px] font-bold text-white rounded ${LEAGUE_COLORS[match.league]}`}>
              {match.league}
            </span>
            <span className="text-xs text-gray-500">{match.leagueName}</span>
          </div>
          <span className={`px-2 py-0.5 text-[10px] font-bold rounded ${isFinished ? 'bg-gray-200 text-gray-600' : 'bg-emerald-100 text-emerald-700'}`}>
            {isFinished ? '경기 종료' : '예정'}
          </span>
        </div>

        {/* 스코어 - 모바일 최적화 */}
        <div className="px-4 py-4">
          <div className="flex items-center justify-between">
            {/* 원정팀 */}
            <div className="flex items-center gap-3 flex-1">
              <TeamLogo src={match.away.logo} team={match.away.teamKo} size="lg" />
              <div>
                <p className="font-bold text-gray-800 text-sm whitespace-nowrap">
                  {language === 'ko' ? match.away.teamKo : match.away.team}
                </p>
                <p className="text-[10px] text-gray-400">원정</p>
              </div>
            </div>

            {/* 스코어 */}
            <div className="flex items-center gap-2 px-3">
              {isFinished ? (
                <>
                  <span className={`text-3xl font-black ${(match.away.score ?? 0) > (match.home.score ?? 0) ? 'text-gray-900' : 'text-gray-300'}`}>
                    {match.away.score}
                  </span>
                  <span className="text-xl text-gray-300">-</span>
                  <span className={`text-3xl font-black ${(match.home.score ?? 0) > (match.away.score ?? 0) ? 'text-gray-900' : 'text-gray-300'}`}>
                    {match.home.score}
                  </span>
                </>
              ) : (
                <div className="text-center">
                  <p className="text-xl font-bold text-gray-300">VS</p>
                </div>
              )}
            </div>

            {/* 홈팀 */}
            <div className="flex items-center gap-3 flex-1 justify-end">
              <div className="text-right">
                <p className="font-bold text-gray-800 text-sm whitespace-nowrap">
                  {language === 'ko' ? match.home.teamKo : match.home.team}
                </p>
                <p className="text-[10px] text-gray-400">홈</p>
              </div>
              <TeamLogo src={match.home.logo} team={match.home.teamKo} size="lg" />
            </div>
          </div>

          {/* 날짜/시간 */}
          <p className="text-center text-xs text-gray-500 mt-3">
            {match.date} {!isFinished && match.time}
          </p>
        </div>
      </div>

      {/* 이닝 스코어 */}
      {isFinished && innings.length > 0 && (
        <div className="bg-white mt-2 border-y">
          <div className="px-4 py-2 bg-gray-800 flex items-center gap-2">
            <span className="text-sm">📊</span>
            <span className="text-white text-xs font-bold">이닝 스코어</span>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-xs">
              <thead className="bg-gray-50">
                <tr>
                  <th className="px-2 py-2 text-left text-gray-500 font-medium w-16">팀</th>
                  {innings.map((inn) => (
                    <th key={inn.inning} className="px-1.5 py-2 text-center text-gray-500 font-medium w-7">{inn.inning}</th>
                  ))}
                  <th className="px-2 py-2 text-center font-bold text-gray-800 bg-gray-100 w-8">R</th>
                </tr>
              </thead>
              <tbody>
                {/* 원정팀 */}
                <tr className="border-t">
                  <td className="px-2 py-2">
                    <div className="flex items-center gap-1">
                      <TeamLogo src={match.away.logo} team={match.away.teamKo} size="sm" />
                      <span className="text-gray-700 font-medium truncate max-w-[40px]">
                        {match.away.teamKo.slice(0, 2)}
                      </span>
                    </div>
                  </td>
                  {innings.map((inn) => (
                    <td key={inn.inning} className="px-1.5 py-2 text-center text-gray-600">{inn.away}</td>
                  ))}
                  <td className={`px-2 py-2 text-center font-bold bg-gray-50 ${(match.away.score ?? 0) > (match.home.score ?? 0) ? 'text-emerald-600' : 'text-gray-700'}`}>
                    {match.away.score}
                  </td>
                </tr>
                {/* 홈팀 */}
                <tr className="border-t">
                  <td className="px-2 py-2">
                    <div className="flex items-center gap-1">
                      <TeamLogo src={match.home.logo} team={match.home.teamKo} size="sm" />
                      <span className="text-gray-700 font-medium truncate max-w-[40px]">
                        {match.home.teamKo.slice(0, 2)}
                      </span>
                    </div>
                  </td>
                  {innings.map((inn) => (
                    <td key={inn.inning} className="px-1.5 py-2 text-center text-gray-600">{inn.home}</td>
                  ))}
                  <td className={`px-2 py-2 text-center font-bold bg-gray-50 ${(match.home.score ?? 0) > (match.away.score ?? 0) ? 'text-emerald-600' : 'text-gray-700'}`}>
                    {match.home.score}
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* AI 예측 - 경기 전에만 표시 */}
      {!isFinished && match.odds && (
        <div className="bg-white mt-2 border-y">
          <div className="px-4 py-2 bg-gradient-to-r from-emerald-600 to-teal-600 flex items-center gap-2">
            <span className="text-sm">🤖</span>
            <span className="text-white text-xs font-bold">AI 예측 분석</span>
          </div>
          <div className="p-4">
            {/* AI 추천 */}
            {(() => {
              const diff = Math.abs(match.odds.homeWinProb - match.odds.awayWinProb)
              const isHomeWin = match.odds.homeWinProb > match.odds.awayWinProb
              const recommendedTeam = isHomeWin 
                ? (language === 'ko' ? match.home.teamKo : match.home.team)
                : (language === 'ko' ? match.away.teamKo : match.away.team)
              const winProb = isHomeWin ? match.odds.homeWinProb : match.odds.awayWinProb
              
              // 등급 결정
              let grade = 'PASS'
              let gradeColor = 'bg-gray-100 text-gray-600 border-gray-200'
              let gradeBg = 'bg-gray-50'
              if (diff >= 20) {
                grade = 'PICK'
                gradeColor = 'bg-emerald-100 text-emerald-700 border-emerald-200'
                gradeBg = 'bg-gradient-to-r from-emerald-50 to-teal-50'
              } else if (diff >= 10) {
                grade = 'GOOD'
                gradeColor = 'bg-blue-100 text-blue-700 border-blue-200'
                gradeBg = 'bg-blue-50'
              }
              
              // 추천 이유
              const reasons = []
              if (diff >= 20) {
                reasons.push(language === 'ko' ? '확률 차이가 크므로 추천합니다' : 'High probability difference')
              }
              if (winProb >= 65) {
                reasons.push(language === 'ko' ? '높은 승률을 보이고 있습니다' : 'High win probability')
              }
              if (diff < 10) {
                reasons.push(language === 'ko' ? '접전이 예상되어 추천을 보류합니다' : 'Close match expected')
              }
              
              return (
                <div className={`rounded-xl p-4 ${gradeBg} border ${grade === 'PICK' ? 'border-emerald-200' : grade === 'GOOD' ? 'border-blue-200' : 'border-gray-200'}`}>
                  {/* 등급 + 추천팀 */}
                  <div className="flex items-center justify-between mb-3">
                    <div className="flex items-center gap-2">
                      <span className={`px-2 py-1 rounded text-xs font-bold ${gradeColor}`}>
                        {grade}
                      </span>
                      {grade !== 'PASS' && (
                        <span className="text-sm font-bold text-gray-800">
                          {recommendedTeam} {language === 'ko' ? '승' : 'Win'}
                        </span>
                      )}
                    </div>
                    <span className={`text-lg font-black ${grade === 'PICK' ? 'text-emerald-600' : grade === 'GOOD' ? 'text-blue-600' : 'text-gray-500'}`}>
                      {winProb}%
                    </span>
                  </div>
                  
                  {/* 신뢰도 바 */}
                  <div className="mb-3">
                    <div className="flex justify-between text-[10px] text-gray-500 mb-1">
                      <span>{language === 'ko' ? '신뢰도' : 'Confidence'}</span>
                      <span>{diff >= 20 ? (language === 'ko' ? '높음' : 'High') : diff >= 10 ? (language === 'ko' ? '보통' : 'Medium') : (language === 'ko' ? '낮음' : 'Low')}</span>
                    </div>
                    <div className="h-2 bg-gray-200 rounded-full overflow-hidden">
                      <div 
                        className={`h-full transition-all ${grade === 'PICK' ? 'bg-emerald-500' : grade === 'GOOD' ? 'bg-blue-500' : 'bg-gray-400'}`}
                        style={{ width: `${Math.min(diff * 3, 100)}%` }}
                      />
                    </div>
                  </div>
                  
                  {/* 추천 이유 */}
                  <div className="text-xs text-gray-600">
                    <p className="flex items-center gap-1">
                      <span>💡</span>
                      {reasons[0] || (language === 'ko' ? '분석 중...' : 'Analyzing...')}
                    </p>
                  </div>
                </div>
              )
            })()}
          </div>
        </div>
      )}

      {/* 배당률 */}
      {match.odds && (
        <div className="bg-white mt-2 border-y">
          <div className="px-4 py-2 bg-gray-800 flex items-center gap-2">
            <span className="text-sm">💰</span>
            <span className="text-white text-xs font-bold">배당률</span>
          </div>
          <div className="p-4">
            {/* 승률 바 */}
            <div className="mb-4">
              <div className="flex justify-between text-xs mb-1">
                <span className="text-blue-600 font-bold">{match.odds.awayWinProb}%</span>
                <span className="text-gray-400">승리 확률</span>
                <span className="text-emerald-600 font-bold">{match.odds.homeWinProb}%</span>
              </div>
              <div className="h-2 bg-gray-200 rounded-full overflow-hidden flex">
                <div className="bg-blue-500 h-full" style={{ width: `${match.odds.awayWinProb}%` }} />
                <div className="bg-emerald-500 h-full" style={{ width: `${match.odds.homeWinProb}%` }} />
              </div>
            </div>

            {/* 배당 */}
            <div className="grid grid-cols-2 gap-3">
              <div className="bg-blue-50 rounded-lg p-3 text-center border border-blue-100">
                <p className="text-[10px] text-blue-500 mb-0.5">{match.away.teamKo} 승</p>
                <p className="text-xl font-bold text-blue-700">{match.odds.awayWinOdds}</p>
              </div>
              <div className="bg-emerald-50 rounded-lg p-3 text-center border border-emerald-100">
                <p className="text-[10px] text-emerald-500 mb-0.5">{match.home.teamKo} 승</p>
                <p className="text-xl font-bold text-emerald-700">{match.odds.homeWinOdds}</p>
              </div>
            </div>

            {/* 오버/언더 */}
            {match.odds.overUnderLine && (
              <div className="mt-3 pt-3 border-t">
                <p className="text-[10px] text-gray-500 text-center mb-2">O/U {match.odds.overUnderLine}</p>
                <div className="grid grid-cols-2 gap-3">
                  <div className="bg-gray-50 rounded p-2 text-center">
                    <span className="text-xs text-gray-500">Over</span>
                    <span className="ml-2 font-bold text-gray-700">{match.odds.overOdds}</span>
                  </div>
                  <div className="bg-gray-50 rounded p-2 text-center">
                    <span className="text-xs text-gray-500">Under</span>
                    <span className="ml-2 font-bold text-gray-700">{match.odds.underOdds}</span>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      )}

      {/* 팀 통계 */}
      {match.teamStats && (
        <div className="bg-white mt-2 border-y">
          <div className="px-4 py-2 bg-gray-800 flex items-center gap-2">
            <span className="text-sm">📈</span>
            <span className="text-white text-xs font-bold">팀 통계</span>
          </div>
          <div className="p-4 space-y-3">
            {/* 승률 */}
            <div className="flex items-center text-xs">
              <span className="w-12 text-right font-bold text-blue-600">{(match.teamStats.away.winRate * 100).toFixed(0)}%</span>
              <div className="flex-1 mx-3">
                <p className="text-center text-gray-400 text-[10px] mb-1">승률</p>
                <div className="h-1.5 bg-gray-200 rounded-full overflow-hidden flex">
                  <div className="bg-blue-500 h-full" style={{ width: `${match.teamStats.away.winRate * 100}%` }} />
                  <div className="flex-1" />
                  <div className="bg-emerald-500 h-full" style={{ width: `${match.teamStats.home.winRate * 100}%` }} />
                </div>
              </div>
              <span className="w-12 text-left font-bold text-emerald-600">{(match.teamStats.home.winRate * 100).toFixed(0)}%</span>
            </div>

            {/* 평균 득점 */}
            <div className="flex items-center text-xs">
              <span className="w-12 text-right font-bold text-blue-600">{match.teamStats.away.avgRuns.toFixed(1)}</span>
              <div className="flex-1 mx-3">
                <p className="text-center text-gray-400 text-[10px] mb-1">평균 득점</p>
                <div className="h-1.5 bg-gray-200 rounded-full overflow-hidden flex">
                  <div className="bg-blue-500 h-full" style={{ width: `${(match.teamStats.away.avgRuns / 8) * 100}%` }} />
                  <div className="flex-1" />
                  <div className="bg-emerald-500 h-full" style={{ width: `${(match.teamStats.home.avgRuns / 8) * 100}%` }} />
                </div>
              </div>
              <span className="w-12 text-left font-bold text-emerald-600">{match.teamStats.home.avgRuns.toFixed(1)}</span>
            </div>

            {/* 최근 폼 */}
            <div className="flex items-center justify-between pt-2">
              <div className="flex gap-0.5">
                {match.teamStats.away.recentForm.split('').map((r, i) => (
                  <span key={i} className={`w-5 h-5 rounded-full text-[10px] text-white font-bold flex items-center justify-center ${
                    r === 'W' ? 'bg-emerald-500' : r === 'L' ? 'bg-red-500' : 'bg-gray-400'
                  }`}>{r}</span>
                ))}
              </div>
              <span className="text-[10px] text-gray-400">최근 5경기</span>
              <div className="flex gap-0.5">
                {match.teamStats.home.recentForm.split('').map((r, i) => (
                  <span key={i} className={`w-5 h-5 rounded-full text-[10px] text-white font-bold flex items-center justify-center ${
                    r === 'W' ? 'bg-emerald-500' : r === 'L' ? 'bg-red-500' : 'bg-gray-400'
                  }`}>{r}</span>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* H2H */}
      {match.h2h && match.h2h.length > 0 && (
        <div className="bg-white mt-2 border-y">
          <div className="px-4 py-2 bg-gray-800 flex items-center gap-2">
            <span className="text-sm">⚔️</span>
            <span className="text-white text-xs font-bold">상대 전적</span>
          </div>
          <div className="divide-y">
            {match.h2h.slice(0, 5).map((game) => (
              <div key={game.id} className="flex items-center px-4 py-2.5 text-xs">
                <span className="text-gray-400 w-16">{game.date.slice(5)}</span>
                <span className="flex-1 text-right text-gray-700 truncate">{game.awayTeam}</span>
                <span className="px-3 font-bold text-gray-800">{game.awayScore} - {game.homeScore}</span>
                <span className="flex-1 text-left text-gray-700 truncate">{game.homeTeam}</span>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* 관련 경기 */}
      {match.relatedMatches && match.relatedMatches.length > 0 && (
        <div className="bg-white mt-2 border-y">
          <div className="px-4 py-2 bg-gray-800 flex items-center gap-2">
            <span className="text-sm">📅</span>
            <span className="text-white text-xs font-bold">관련 경기</span>
          </div>
          <div className="divide-y">
            {match.relatedMatches.slice(0, 3).map((related) => (
              <Link key={related.id} href={`/baseball/${related.id}`} className="flex items-center px-4 py-3 hover:bg-gray-50">
                <span className="text-[10px] text-gray-400 w-12">{related.date?.slice(5)}</span>
                <div className="flex items-center gap-1.5 flex-1">
                  <TeamLogo src={related.awayLogo} team={related.awayTeam} size="sm" />
                  <span className="text-xs text-gray-700 truncate">{related.awayTeam}</span>
                </div>
                <div className="px-2 text-center">
                  {related.status === 'FT' ? (
                    <span className="text-xs font-bold text-gray-800">{related.awayScore} - {related.homeScore}</span>
                  ) : (
                    <span className="text-[10px] text-gray-500">{related.time?.slice(0, 5)}</span>
                  )}
                </div>
                <div className="flex items-center gap-1.5 flex-1 justify-end">
                  <span className="text-xs text-gray-700 truncate">{related.homeTeam}</span>
                  <TeamLogo src={related.homeLogo} team={related.homeTeam} size="sm" />
                </div>
              </Link>
            ))}
          </div>
        </div>
      )}

      {/* 하단 여백 */}
      <div className="h-4" />
    </div>
  )
}