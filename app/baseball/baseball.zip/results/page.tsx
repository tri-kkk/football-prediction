'use client'

import { useState, useEffect } from 'react'
import Link from 'next/link'
import { useLanguage } from '../../contexts/LanguageContext'

// =====================================================
// 타입 정의
// =====================================================
interface Match {
  id: number
  league: string
  leagueName: string
  date: string
  time: string
  timestamp: string
  homeTeam: string
  homeTeamKo: string
  homeLogo: string
  homeScore: number | null
  awayTeam: string
  awayTeamKo: string
  awayLogo: string
  awayScore: number | null
  status: string
  innings?: {
    home: Record<string, number | null>
    away: Record<string, number | null>
  } | null
  odds?: {
    homeWinProb: number
    awayWinProb: number
  } | null
}

// =====================================================
// 상수
// =====================================================
const LEAGUES = [
  { id: 'ALL', name: '전체', nameEn: 'All' },
  { id: 'KBO', name: 'KBO', nameEn: 'KBO' },
  { id: 'MLB', name: 'MLB', nameEn: 'MLB' },
  { id: 'NPB', name: 'NPB', nameEn: 'NPB' },
  { id: 'CPBL', name: 'CPBL', nameEn: 'CPBL' },
]

const LEAGUE_COLORS: Record<string, string> = {
  KBO: 'bg-red-500',
  NPB: 'bg-orange-500',
  MLB: 'bg-blue-600',
  CPBL: 'bg-purple-500',
}

// =====================================================
// 샘플 데이터
// =====================================================

// 예정 경기
const SAMPLE_SCHEDULED: Match[] = [
  {
    id: 8001,
    league: 'KBO',
    leagueName: 'KBO League',
    date: '2025-03-22',
    time: '14:00',
    timestamp: '2025-03-22T05:00:00Z',
    homeTeam: 'LG Twins',
    homeTeamKo: 'LG 트윈스',
    homeLogo: 'https://media.api-sports.io/baseball/teams/3916.png',
    homeScore: null,
    awayTeam: 'Samsung Lions',
    awayTeamKo: '삼성 라이온즈',
    awayLogo: 'https://media.api-sports.io/baseball/teams/3920.png',
    awayScore: null,
    status: 'scheduled',
    odds: { homeWinProb: 62, awayWinProb: 38 }
  },
  {
    id: 8002,
    league: 'KBO',
    leagueName: 'KBO League',
    date: '2025-03-22',
    time: '14:00',
    timestamp: '2025-03-22T05:00:00Z',
    homeTeam: 'Doosan Bears',
    homeTeamKo: '두산 베어스',
    homeLogo: 'https://media.api-sports.io/baseball/teams/3912.png',
    homeScore: null,
    awayTeam: 'KIA Tigers',
    awayTeamKo: 'KIA 타이거즈',
    awayLogo: 'https://media.api-sports.io/baseball/teams/3915.png',
    awayScore: null,
    status: 'scheduled',
    odds: { homeWinProb: 55, awayWinProb: 45 }
  },
  {
    id: 8003,
    league: 'KBO',
    leagueName: 'KBO League',
    date: '2025-03-23',
    time: '17:00',
    timestamp: '2025-03-23T08:00:00Z',
    homeTeam: 'SSG Landers',
    homeTeamKo: 'SSG 랜더스',
    homeLogo: 'https://media.api-sports.io/baseball/teams/3921.png',
    homeScore: null,
    awayTeam: 'NC Dinos',
    awayTeamKo: 'NC 다이노스',
    awayLogo: 'https://media.api-sports.io/baseball/teams/3919.png',
    awayScore: null,
    status: 'scheduled',
    odds: { homeWinProb: 68, awayWinProb: 32 }
  },
  {
    id: 8004,
    league: 'MLB',
    leagueName: 'MLB',
    date: '2025-03-23',
    time: '19:10',
    timestamp: '2025-03-23T23:10:00Z',
    homeTeam: 'LA Dodgers',
    homeTeamKo: 'LA 다저스',
    homeLogo: 'https://media.api-sports.io/baseball/teams/20.png',
    homeScore: null,
    awayTeam: 'NY Yankees',
    awayTeamKo: 'NY 양키스',
    awayLogo: 'https://media.api-sports.io/baseball/teams/1.png',
    awayScore: null,
    status: 'scheduled',
    odds: { homeWinProb: 52, awayWinProb: 48 }
  },
]

// 종료 경기
const SAMPLE_FINISHED: Match[] = [
  {
    id: 9001,
    league: 'KBO',
    leagueName: 'KBO League',
    date: '2025-01-11',
    time: '14:00',
    timestamp: '2025-01-11T05:00:00Z',
    homeTeam: 'LG Twins',
    homeTeamKo: 'LG 트윈스',
    homeLogo: 'https://media.api-sports.io/baseball/teams/3916.png',
    homeScore: 7,
    awayTeam: 'Samsung Lions',
    awayTeamKo: '삼성 라이온즈',
    awayLogo: 'https://media.api-sports.io/baseball/teams/3920.png',
    awayScore: 3,
    status: 'finished',
    innings: {
      home: { '1': 2, '2': 0, '3': 1, '4': 0, '5': 2, '6': 0, '7': 1, '8': 1, '9': 0 },
      away: { '1': 0, '2': 1, '3': 0, '4': 0, '5': 1, '6': 0, '7': 0, '8': 1, '9': 0 }
    },
    odds: { homeWinProb: 62, awayWinProb: 38 }
  },
  {
    id: 9002,
    league: 'KBO',
    leagueName: 'KBO League',
    date: '2025-01-11',
    time: '14:00',
    timestamp: '2025-01-11T05:00:00Z',
    homeTeam: 'Doosan Bears',
    homeTeamKo: '두산 베어스',
    homeLogo: 'https://media.api-sports.io/baseball/teams/3912.png',
    homeScore: 4,
    awayTeam: 'KIA Tigers',
    awayTeamKo: 'KIA 타이거즈',
    awayLogo: 'https://media.api-sports.io/baseball/teams/3915.png',
    awayScore: 5,
    status: 'finished',
    innings: {
      home: { '1': 1, '2': 0, '3': 2, '4': 0, '5': 0, '6': 1, '7': 0, '8': 0, '9': 0 },
      away: { '1': 0, '2': 2, '3': 0, '4': 1, '5': 0, '6': 0, '7': 1, '8': 0, '9': 1 }
    },
    odds: { homeWinProb: 55, awayWinProb: 45 }
  },
  {
    id: 9003,
    league: 'MLB',
    leagueName: 'MLB',
    date: '2025-01-10',
    time: '19:10',
    timestamp: '2025-01-10T23:10:00Z',
    homeTeam: 'New York Yankees',
    homeTeamKo: '뉴욕 양키스',
    homeLogo: 'https://media.api-sports.io/baseball/teams/1.png',
    homeScore: 5,
    awayTeam: 'Boston Red Sox',
    awayTeamKo: '보스턴 레드삭스',
    awayLogo: 'https://media.api-sports.io/baseball/teams/2.png',
    awayScore: 2,
    status: 'finished',
    innings: {
      home: { '1': 0, '2': 2, '3': 0, '4': 1, '5': 0, '6': 0, '7': 2, '8': 0, '9': 0 },
      away: { '1': 1, '2': 0, '3': 0, '4': 0, '5': 0, '6': 1, '7': 0, '8': 0, '9': 0 }
    },
    odds: { homeWinProb: 58, awayWinProb: 42 }
  },
  {
    id: 9004,
    league: 'NPB',
    leagueName: 'NPB',
    date: '2025-01-10',
    time: '18:00',
    timestamp: '2025-01-10T09:00:00Z',
    homeTeam: 'Yomiuri Giants',
    homeTeamKo: '요미우리 자이언츠',
    homeLogo: 'https://media.api-sports.io/baseball/teams/287.png',
    homeScore: 3,
    awayTeam: 'Hanshin Tigers',
    awayTeamKo: '한신 타이거스',
    awayLogo: 'https://media.api-sports.io/baseball/teams/282.png',
    awayScore: 4,
    status: 'finished',
    odds: { homeWinProb: 52, awayWinProb: 48 }
  },
]

// =====================================================
// 유틸리티 함수
// =====================================================
function formatDate(dateStr: string, lang: 'ko' | 'en'): string {
  const date = new Date(dateStr)
  if (lang === 'ko') {
    return date.toLocaleDateString('ko-KR', { month: 'short', day: 'numeric', weekday: 'short' })
  }
  return date.toLocaleDateString('en-US', { month: 'short', day: 'numeric', weekday: 'short' })
}

function getMatchResult(match: Match): 'HOME' | 'AWAY' | 'DRAW' | null {
  if (match.homeScore === null || match.awayScore === null) return null
  if (match.homeScore > match.awayScore) return 'HOME'
  if (match.homeScore < match.awayScore) return 'AWAY'
  return 'DRAW'
}

function getPrediction(match: Match): 'HOME' | 'AWAY' | 'NONE' {
  if (!match.odds) return 'NONE'
  const diff = Math.abs(match.odds.homeWinProb - match.odds.awayWinProb)
  if (diff < 10) return 'NONE'
  return match.odds.homeWinProb > match.odds.awayWinProb ? 'HOME' : 'AWAY'
}

function isPredictionCorrect(match: Match): boolean | null {
  const result = getMatchResult(match)
  const prediction = getPrediction(match)
  if (result === null || prediction === 'NONE' || result === 'DRAW') return null
  return result === prediction
}

function getGrade(match: Match): { grade: string; color: string; bgColor: string } {
  if (!match.odds) return { grade: 'PASS', color: 'text-gray-500', bgColor: 'bg-gray-100' }
  const diff = Math.abs(match.odds.homeWinProb - match.odds.awayWinProb)
  if (diff >= 20) return { grade: 'PICK', color: 'text-emerald-600', bgColor: 'bg-emerald-100' }
  if (diff >= 10) return { grade: 'GOOD', color: 'text-blue-600', bgColor: 'bg-blue-100' }
  return { grade: 'PASS', color: 'text-gray-500', bgColor: 'bg-gray-100' }
}

// =====================================================
// 컴포넌트
// =====================================================
function TeamLogo({ src, team, size = 'md' }: { src?: string; team: string; size?: 'sm' | 'md' | 'lg' }) {
  const sizeClasses = {
    sm: 'w-6 h-6 text-[10px]',
    md: 'w-10 h-10 text-xs',
    lg: 'w-14 h-14 text-sm',
  }
  
  if (src) {
    return (
      <img 
        src={src} 
        alt={team} 
        className={`${sizeClasses[size]} object-contain`}
        onError={(e) => {
          (e.target as HTMLImageElement).style.display = 'none'
        }}
      />
    )
  }
  
  return (
    <div className={`${sizeClasses[size]} rounded-full bg-gray-200 flex items-center justify-center font-bold text-gray-500`}>
      {team.substring(0, 2)}
    </div>
  )
}

// 이닝 스코어 테이블
function InningsTable({ match, language }: { match: Match; language: 'ko' | 'en' }) {
  if (!match.innings) return null
  
  const innings = Object.keys(match.innings.home).sort((a, b) => parseInt(a) - parseInt(b))
  
  return (
    <div className="overflow-x-auto">
      <table className="w-full text-xs">
        <thead>
          <tr className="bg-gray-100">
            <th className="px-2 py-1 text-left font-medium text-gray-500 w-20">
              {language === 'ko' ? '팀' : 'Team'}
            </th>
            {innings.map(inning => (
              <th key={inning} className="px-1.5 py-1 text-center font-medium text-gray-500 w-6">
                {inning}
              </th>
            ))}
            <th className="px-2 py-1 text-center font-bold text-gray-700 w-8">R</th>
          </tr>
        </thead>
        <tbody>
          <tr className="border-b border-gray-100">
            <td className="px-2 py-1.5 font-medium text-gray-700 truncate max-w-[80px]">
              {language === 'ko' ? match.awayTeamKo?.split(' ')[0] || match.awayTeam.split(' ')[0] : match.awayTeam.split(' ')[0]}
            </td>
            {innings.map(inning => (
              <td key={inning} className="px-1.5 py-1.5 text-center text-gray-600">
                {match.innings?.away[inning] ?? '-'}
              </td>
            ))}
            <td className="px-2 py-1.5 text-center font-bold text-gray-800">{match.awayScore}</td>
          </tr>
          <tr>
            <td className="px-2 py-1.5 font-medium text-gray-700 truncate max-w-[80px]">
              {language === 'ko' ? match.homeTeamKo?.split(' ')[0] || match.homeTeam.split(' ')[0] : match.homeTeam.split(' ')[0]}
            </td>
            {innings.map(inning => (
              <td key={inning} className="px-1.5 py-1.5 text-center text-gray-600">
                {match.innings?.home[inning] ?? '-'}
              </td>
            ))}
            <td className="px-2 py-1.5 text-center font-bold text-gray-800">{match.homeScore}</td>
          </tr>
        </tbody>
      </table>
    </div>
  )
}

// 경기 카드 (예정/종료 공통)
function MatchCard({ match, language, isScheduled, isSample = false }: { 
  match: Match; 
  language: 'ko' | 'en'; 
  isScheduled: boolean;
  isSample?: boolean 
}) {
  const homeTeamName = language === 'ko' ? match.homeTeamKo || match.homeTeam : match.homeTeam
  const awayTeamName = language === 'ko' ? match.awayTeamKo || match.awayTeam : match.awayTeam
  const result = getMatchResult(match)
  const prediction = getPrediction(match)
  const isCorrect = isPredictionCorrect(match)
  const { grade, color, bgColor } = getGrade(match)
  const isHomeWin = match.odds && match.odds.homeWinProb > match.odds.awayWinProb
  const winProb = match.odds ? Math.max(match.odds.homeWinProb, match.odds.awayWinProb) : 50
  
  return (
    <Link 
      href={`/baseball/${match.id}`}
      className={`block bg-white rounded-2xl shadow-lg overflow-hidden border border-gray-100 hover:shadow-xl transition-all ${isSample ? 'opacity-90' : ''}`}
    >
      {/* 헤더 */}
      <div className="flex items-center justify-between px-4 py-2 bg-gray-50 border-b border-gray-100">
        <div className="flex items-center gap-2">
          <span className={`px-2 py-0.5 rounded text-xs font-bold text-white ${LEAGUE_COLORS[match.league] || 'bg-gray-500'}`}>
            {match.league}
          </span>
          <span className="text-xs text-gray-500">
            {formatDate(match.date, language)} {match.time}
          </span>
          {isSample && (
            <span className="px-1.5 py-0.5 bg-blue-100 text-blue-600 text-[10px] rounded font-medium">
              SAMPLE
            </span>
          )}
        </div>
        {isScheduled ? (
          <span className={`px-2 py-0.5 rounded text-xs font-bold ${bgColor} ${color}`}>
            {grade}
          </span>
        ) : (
          <span className="px-2 py-0.5 bg-gray-200 text-gray-600 rounded text-xs font-medium">
            {language === 'ko' ? '종료' : 'Final'}
          </span>
        )}
      </div>
      
      {/* 매치업 + 스코어/VS */}
      <div className="p-4">
        <div className="flex items-center justify-between mb-3">
          {/* 원정팀 */}
          <div className="flex items-center gap-3 flex-1">
            <TeamLogo src={match.awayLogo} team={match.awayTeam} size="lg" />
            <div>
              <p className={`font-bold text-sm ${
                isScheduled 
                  ? (!isHomeWin ? 'text-gray-900' : 'text-gray-500')
                  : (result === 'AWAY' ? 'text-gray-900' : 'text-gray-400')
              }`}>
                {awayTeamName}
              </p>
              <p className="text-xs text-gray-400">{language === 'ko' ? '원정' : 'Away'}</p>
            </div>
          </div>
          
          {/* 스코어 or VS */}
          <div className="flex items-center gap-3 px-4">
            {isScheduled ? (
              <span className="text-xl font-bold text-gray-300">VS</span>
            ) : (
              <>
                <span className={`text-3xl font-bold ${result === 'AWAY' ? 'text-gray-900' : 'text-gray-400'}`}>
                  {match.awayScore}
                </span>
                <span className="text-gray-300 text-xl">-</span>
                <span className={`text-3xl font-bold ${result === 'HOME' ? 'text-gray-900' : 'text-gray-400'}`}>
                  {match.homeScore}
                </span>
              </>
            )}
          </div>
          
          {/* 홈팀 */}
          <div className="flex items-center gap-3 flex-1 justify-end text-right">
            <div>
              <p className={`font-bold text-sm ${
                isScheduled 
                  ? (isHomeWin ? 'text-gray-900' : 'text-gray-500')
                  : (result === 'HOME' ? 'text-gray-900' : 'text-gray-400')
              }`}>
                {homeTeamName}
              </p>
              <p className="text-xs text-gray-400">{language === 'ko' ? '홈' : 'Home'}</p>
            </div>
            <TeamLogo src={match.homeLogo} team={match.homeTeam} size="lg" />
          </div>
        </div>
        
        {/* 예정 경기: AI 예측 바 + 추천 */}
        {isScheduled && match.odds && (
          <>
            <div className="mt-3">
              <div className="flex justify-between text-xs mb-1">
                <span className={`font-bold ${!isHomeWin ? 'text-blue-600' : 'text-gray-400'}`}>
                  {match.odds.awayWinProb}%
                </span>
                <span className="text-gray-400">{language === 'ko' ? 'AI 예측' : 'AI Prediction'}</span>
                <span className={`font-bold ${isHomeWin ? 'text-emerald-600' : 'text-gray-400'}`}>
                  {match.odds.homeWinProb}%
                </span>
              </div>
              <div className="h-2 bg-gray-200 rounded-full overflow-hidden flex">
                <div 
                  className={`h-full ${!isHomeWin ? 'bg-blue-500' : 'bg-blue-300'}`} 
                  style={{ width: `${match.odds.awayWinProb}%` }} 
                />
                <div 
                  className={`h-full ${isHomeWin ? 'bg-emerald-500' : 'bg-emerald-300'}`} 
                  style={{ width: `${match.odds.homeWinProb}%` }} 
                />
              </div>
            </div>
            
            {grade !== 'PASS' && (
              <div className={`mt-3 p-2 rounded-lg ${grade === 'PICK' ? 'bg-emerald-50 border border-emerald-200' : 'bg-blue-50 border border-blue-200'}`}>
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span className="text-sm">🤖</span>
                    <span className={`text-xs font-bold ${grade === 'PICK' ? 'text-emerald-700' : 'text-blue-700'}`}>
                      {isHomeWin ? homeTeamName : awayTeamName} {language === 'ko' ? '승 추천' : 'Win'}
                    </span>
                  </div>
                  <span className={`text-sm font-black ${grade === 'PICK' ? 'text-emerald-600' : 'text-blue-600'}`}>
                    {winProb}%
                  </span>
                </div>
              </div>
            )}
          </>
        )}
        
        {/* 종료 경기: 이닝 스코어 + 적중 결과 */}
        {!isScheduled && (
          <>
            {match.innings && (
              <div className="mb-3 bg-gray-50 rounded-xl p-2">
                <InningsTable match={match} language={language} />
              </div>
            )}
            
            {prediction !== 'NONE' && (
              <div className={`rounded-xl p-3 ${isCorrect ? 'bg-gradient-to-r from-emerald-50 to-green-50 border border-emerald-200' : 'bg-gradient-to-r from-red-50 to-orange-50 border border-red-200'}`}>
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span className="text-lg">{isCorrect ? '✅' : '❌'}</span>
                    <div>
                      <p className="text-xs text-gray-500">
                        {language === 'ko' ? 'AI 예측' : 'AI Prediction'}
                      </p>
                      <p className={`font-bold text-sm ${isCorrect ? 'text-emerald-700' : 'text-red-600'}`}>
                        {prediction === 'HOME' ? homeTeamName : awayTeamName} {language === 'ko' ? '승' : 'Win'}
                      </p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="text-xs text-gray-500">{language === 'ko' ? '예측 확률' : 'Probability'}</p>
                    <p className="font-bold text-gray-700">
                      {prediction === 'HOME' ? match.odds?.homeWinProb : match.odds?.awayWinProb}%
                    </p>
                  </div>
                </div>
              </div>
            )}
            
            {prediction === 'NONE' && (
              <div className="rounded-xl p-3 bg-gray-50 border border-gray-200">
                <div className="flex items-center gap-2 text-gray-500">
                  <span>⚠️</span>
                  <span className="text-xs">
                    {language === 'ko' ? '접전 예상으로 추천 없음' : 'No pick - Close match'}
                  </span>
                </div>
              </div>
            )}
          </>
        )}
      </div>
    </Link>
  )
}

// =====================================================
// 메인 페이지 컴포넌트
// =====================================================
export default function BaseballMatchesPage() {
  const { language } = useLanguage()
  const [activeTab, setActiveTab] = useState<'scheduled' | 'finished'>('scheduled')
  const [selectedLeague, setSelectedLeague] = useState('ALL')
  const [selectedDate, setSelectedDate] = useState<string>('ALL')
  const [matches, setMatches] = useState<Match[]>([])
  const [loading, setLoading] = useState(true)
  const [usingSampleData, setUsingSampleData] = useState(false)
  
  // 날짜 생성 (예정: 앞으로 7일 / 종료: 과거 7일)
  const getDates = () => {
    const dates = []
    for (let i = 0; i < 7; i++) {
      const date = new Date()
      if (activeTab === 'scheduled') {
        date.setDate(date.getDate() + i)
      } else {
        date.setDate(date.getDate() - i)
      }
      const dateStr = date.toISOString().split('T')[0]
      const dayNames = language === 'ko' 
        ? ['일', '월', '화', '수', '목', '금', '토']
        : ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat']
      dates.push({
        value: dateStr,
        label: i === 0 
          ? (language === 'ko' ? '오늘' : 'Today')
          : i === 1 
            ? (activeTab === 'scheduled' 
                ? (language === 'ko' ? '내일' : 'Tomorrow')
                : (language === 'ko' ? '어제' : 'Yesterday'))
            : `${date.getMonth() + 1}/${date.getDate()}`,
        day: dayNames[date.getDay()],
      })
    }
    return dates
  }
  
  const dates = getDates()
  
  // 경기 데이터 로드
  useEffect(() => {
    const fetchMatches = async () => {
      setLoading(true)
      setSelectedDate('ALL') // 탭 변경 시 날짜 필터 초기화
      
      try {
        const params = new URLSearchParams()
        if (selectedLeague !== 'ALL') {
          params.append('league', selectedLeague)
        }
        params.append('status', activeTab === 'scheduled' ? 'scheduled' : 'finished')
        params.append('limit', '30')
        
        const response = await fetch(`/api/baseball/matches?${params}`)
        const data = await response.json()
        
        if (data.success && data.matches && data.matches.length > 0) {
          const sorted = data.matches.sort((a: Match, b: Match) => {
            if (activeTab === 'scheduled') {
              return new Date(a.date).getTime() - new Date(b.date).getTime()
            }
            return new Date(b.date).getTime() - new Date(a.date).getTime()
          })
          setMatches(sorted)
          setUsingSampleData(false)
        } else {
          const samples = activeTab === 'scheduled' ? SAMPLE_SCHEDULED : SAMPLE_FINISHED
          const filteredSamples = selectedLeague === 'ALL' 
            ? samples 
            : samples.filter(m => m.league === selectedLeague)
          setMatches(filteredSamples)
          setUsingSampleData(true)
        }
      } catch (error) {
        console.error('Failed to fetch matches:', error)
        const samples = activeTab === 'scheduled' ? SAMPLE_SCHEDULED : SAMPLE_FINISHED
        const filteredSamples = selectedLeague === 'ALL' 
          ? samples 
          : samples.filter(m => m.league === selectedLeague)
        setMatches(filteredSamples)
        setUsingSampleData(true)
      } finally {
        setLoading(false)
      }
    }
    
    fetchMatches()
  }, [selectedLeague, activeTab])
  
  // 날짜 필터링
  const filteredMatches = selectedDate === 'ALL' 
    ? matches 
    : matches.filter(m => m.date === selectedDate)
  
  // 통계 계산
  const stats = activeTab === 'scheduled' 
    ? {
        total: filteredMatches.length,
        pick: filteredMatches.filter(m => {
          if (!m.odds) return false
          return Math.abs(m.odds.homeWinProb - m.odds.awayWinProb) >= 20
        }).length,
        good: filteredMatches.filter(m => {
          if (!m.odds) return false
          const diff = Math.abs(m.odds.homeWinProb - m.odds.awayWinProb)
          return diff >= 10 && diff < 20
        }).length,
      }
    : {
        total: filteredMatches.length,
        correct: filteredMatches.filter(m => isPredictionCorrect(m) === true).length,
        wrong: filteredMatches.filter(m => isPredictionCorrect(m) === false).length,
      }
  
  const accuracyRate = activeTab === 'finished' && (stats as any).correct + (stats as any).wrong > 0 
    ? Math.round(((stats as any).correct / ((stats as any).correct + (stats as any).wrong)) * 100) 
    : 0

  return (
    <div className="min-h-screen bg-gray-100">
      {/* 히어로 섹션 */}
      <div className={`text-white ${activeTab === 'scheduled' ? 'bg-gradient-to-r from-emerald-600 to-teal-600' : 'bg-gradient-to-r from-blue-600 to-indigo-600'}`}>
        <div className="max-w-7xl mx-auto px-4 py-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <span className="text-xl">{activeTab === 'scheduled' ? '📅' : '📊'}</span>
              <h1 className="text-sm font-bold">
                {language === 'ko' ? '야구 경기' : 'Baseball'}
              </h1>
            </div>
            
            {/* 통계 */}
            <div className="flex items-center gap-1.5">
              <div className="bg-white/10 rounded px-2 py-1 text-center min-w-[36px]">
                <p className="text-sm font-bold">{stats.total}</p>
                <p className="text-[8px] opacity-70">{language === 'ko' ? '전체' : 'All'}</p>
              </div>
              {activeTab === 'scheduled' ? (
                <>
                  <div className="bg-emerald-400/20 rounded px-2 py-1 text-center min-w-[36px]">
                    <p className="text-sm font-bold">{(stats as any).pick}</p>
                    <p className="text-[8px] text-emerald-200">PICK</p>
                  </div>
                  <div className="bg-blue-400/20 rounded px-2 py-1 text-center min-w-[36px]">
                    <p className="text-sm font-bold">{(stats as any).good}</p>
                    <p className="text-[8px] text-blue-200">GOOD</p>
                  </div>
                </>
              ) : (
                <>
                  <div className="bg-emerald-400/20 rounded px-2 py-1 text-center min-w-[36px]">
                    <p className="text-sm font-bold">{(stats as any).correct}</p>
                    <p className="text-[8px] text-emerald-200">{language === 'ko' ? '적중' : 'Hit'}</p>
                  </div>
                  <div className="bg-red-400/20 rounded px-2 py-1 text-center min-w-[36px]">
                    <p className="text-sm font-bold">{(stats as any).wrong}</p>
                    <p className="text-[8px] text-red-200">{language === 'ko' ? '미스' : 'Miss'}</p>
                  </div>
                  <div className="bg-yellow-400/30 rounded px-2 py-1 text-center min-w-[36px]">
                    <p className="text-sm font-bold">{accuracyRate}%</p>
                    <p className="text-[8px] text-yellow-200">{language === 'ko' ? '율' : 'Rate'}</p>
                  </div>
                </>
              )}
            </div>
          </div>
        </div>
      </div>
      
      {/* 비시즌 안내 */}
      {usingSampleData && (
        <div className="bg-amber-50 border-b border-amber-100">
          <p className="text-[11px] text-amber-600 text-center py-1.5 px-4">
            ⚠️ {language === 'ko' ? '비시즌 - 샘플 데이터 (시즌 시작: 2025년 3월)' : 'Off-season - Sample data'}
          </p>
        </div>
      )}
      
      {/* 탭 + 필터 */}
      <div className="sticky top-0 z-40 bg-white shadow-md">
        <div className="max-w-7xl mx-auto px-4">
          {/* 예정/종료 탭 */}
          <div className="flex border-b border-gray-200">
            <button
              onClick={() => setActiveTab('scheduled')}
              className={`flex-1 py-3 text-sm font-bold text-center transition-all relative ${
                activeTab === 'scheduled'
                  ? 'text-emerald-600'
                  : 'text-gray-400 hover:text-gray-600'
              }`}
            >
              {language === 'ko' ? '예정' : 'Upcoming'}
              {activeTab === 'scheduled' && (
                <div className="absolute bottom-0 left-0 right-0 h-0.5 bg-emerald-600" />
              )}
            </button>
            <button
              onClick={() => setActiveTab('finished')}
              className={`flex-1 py-3 text-sm font-bold text-center transition-all relative ${
                activeTab === 'finished'
                  ? 'text-blue-600'
                  : 'text-gray-400 hover:text-gray-600'
              }`}
            >
              {language === 'ko' ? '종료' : 'Finished'}
              {activeTab === 'finished' && (
                <div className="absolute bottom-0 left-0 right-0 h-0.5 bg-blue-600" />
              )}
            </button>
          </div>
          
          {/* 날짜 선택 */}
          <div className="flex items-center gap-2 py-2 border-b border-gray-100 overflow-x-auto scrollbar-hide">
            <button
              onClick={() => setSelectedDate('ALL')}
              className={`flex-shrink-0 px-3 py-1.5 rounded-lg text-xs font-medium transition-all ${
                selectedDate === 'ALL'
                  ? 'bg-gray-900 text-white'
                  : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
              }`}
            >
              {language === 'ko' ? '전체' : 'All'}
            </button>
            {dates.map((date) => (
              <button
                key={date.value}
                onClick={() => setSelectedDate(date.value)}
                className={`flex-shrink-0 px-3 py-1.5 rounded-lg text-xs transition-all ${
                  selectedDate === date.value
                    ? activeTab === 'scheduled' 
                      ? 'bg-emerald-600 text-white font-bold'
                      : 'bg-blue-600 text-white font-bold'
                    : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
                }`}
              >
                <span className="font-medium">{date.label}</span>
                <span className={`ml-1 ${selectedDate === date.value ? 'opacity-70' : 'text-gray-400'}`}>
                  ({date.day})
                </span>
              </button>
            ))}
          </div>
          
          {/* 리그 선택 */}
          <div className="flex gap-2 py-2 overflow-x-auto scrollbar-hide">
            {LEAGUES.map(league => (
              <button
                key={league.id}
                onClick={() => setSelectedLeague(league.id)}
                className={`px-4 py-2 rounded-full text-sm font-medium whitespace-nowrap transition-all ${
                  selectedLeague === league.id
                    ? activeTab === 'scheduled'
                      ? 'bg-emerald-600 text-white shadow-md'
                      : 'bg-blue-600 text-white shadow-md'
                    : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
                }`}
              >
                {language === 'ko' ? league.name : league.nameEn}
              </button>
            ))}
          </div>
        </div>
      </div>
      
      {/* 적중률 바 (종료 탭에서만) */}
      {activeTab === 'finished' && (stats as any).correct + (stats as any).wrong > 0 && (
        <div className="max-w-7xl mx-auto px-4 py-2">
          <div className="flex items-center gap-3 text-xs">
            <span className="text-gray-500">📈</span>
            <div className="flex-1 h-1.5 bg-gray-200 rounded-full overflow-hidden">
              <div 
                className="h-full bg-emerald-500 transition-all duration-500"
                style={{ width: `${accuracyRate}%` }}
              />
            </div>
            <span className="font-bold text-emerald-600">{accuracyRate}%</span>
          </div>
        </div>
      )}
      
      {/* 경기 카드 목록 */}
      <div className="max-w-7xl mx-auto px-4 pb-24 pt-4">
        {loading ? (
          <div className="flex flex-col items-center justify-center py-20">
            <div className={`animate-spin rounded-full h-12 w-12 border-b-2 mb-4 ${activeTab === 'scheduled' ? 'border-emerald-500' : 'border-blue-500'}`}></div>
            <p className="text-gray-500">
              {language === 'ko' ? '불러오는 중...' : 'Loading...'}
            </p>
          </div>
        ) : filteredMatches.length === 0 ? (
          <div className="text-center py-20">
            <span className="text-6xl mb-4 block">⚾</span>
            <p className="text-gray-500">
              {activeTab === 'scheduled'
                ? (language === 'ko' ? '예정된 경기가 없습니다' : 'No scheduled matches')
                : (language === 'ko' ? '종료된 경기가 없습니다' : 'No finished matches')
              }
            </p>
          </div>
        ) : (
          <div className="space-y-4">
            {/* 날짜별 그룹핑 */}
            {Object.entries(
              filteredMatches.reduce((groups: Record<string, Match[]>, match) => {
                const date = match.date
                if (!groups[date]) groups[date] = []
                groups[date].push(match)
                return groups
              }, {})
            )
            .sort(([a], [b]) => {
              if (activeTab === 'scheduled') {
                return new Date(a).getTime() - new Date(b).getTime()
              }
              return new Date(b).getTime() - new Date(a).getTime()
            })
            .map(([date, dateMatches]) => (
              <div key={date}>
                {/* 날짜 헤더 */}
                {selectedDate === 'ALL' && (
                  <div className="flex items-center gap-2 mb-2 mt-4 first:mt-0">
                    <span className={`text-xs font-bold text-white px-2 py-1 rounded ${activeTab === 'scheduled' ? 'bg-emerald-600' : 'bg-blue-600'}`}>
                      {formatDate(date, language)}
                    </span>
                    <span className="text-xs text-gray-400">
                      {dateMatches.length}{language === 'ko' ? '경기' : ' games'}
                    </span>
                  </div>
                )}
                <div className="grid md:grid-cols-2 gap-4">
                  {dateMatches.map((match) => (
                    <MatchCard
                      key={match.id}
                      match={match}
                      language={language}
                      isScheduled={activeTab === 'scheduled'}
                      isSample={usingSampleData}
                    />
                  ))}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  )
}