Dreamina(Seedance)에서 뽑은 9:16 배경 영상을 여기에 넣으세요.

  bg-hook.mp4      훅 (3초+)
  bg-matchup.mp4   매치업 (4초+)
  bg-pitcher.mp4   투수 비교 (6초+)
  bg-winrate.mp4   승률 (6초+)
  bg-cta.mp4       CTA (5초+)

규격: 1080x1920, 무음, 24fps 이상. 루프되므로 짧아도 됩니다.
파일이 없으면 자동으로 그라디언트 배경으로 폴백합니다.
프롬프트는 README_SHORTS.md 참고.
