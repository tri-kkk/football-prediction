// remotion/theme.ts
// 네이티브 1080x1920 기준 디자인 토큰.
// 기존 ShortsGenerator 는 360x640 캔버스에 그린 뒤 화면녹화로 3배 확대했기 때문에
// 텍스트/로고가 전부 업스케일 되어 뭉개졌다. 여기서는 처음부터 3배 크기로 그린다.

export const WIDTH = 1080
export const HEIGHT = 1920
export const FPS = 60

/** 구버전(360px 캔버스) 수치를 그대로 옮길 때 쓰는 배율 */
export const S = 3

export const BRAND_C1 = '#A3FF4C'
export const BRAND_C2 = '#62F4FF'

export const LEAGUE_BADGE: Record<string, { bg: string; fg: string }> = {
  KBO: { bg: '#D5001C', fg: '#FFFFFF' },
  NPB: { bg: '#0B2D5E', fg: '#FFFFFF' },
  MLB: { bg: '#002D72', fg: '#FFFFFF' },
}

export type SceneKey = 'hook' | 'matchup' | 'pitcher' | 'winrate' | 'cta'

/**
 * 씬 길이 (프레임, 60fps).
 * 구버전 총 26.6초 → 21.5초로 단축.
 * 특히 훅을 3.8초 → 2.2초로 줄였다. 숏폼 이탈은 대부분 첫 2초에 일어난다.
 */
export const SCENES: { key: SceneKey; frames: number }[] = [
  { key: 'hook', frames: 132 },     // 2.2s
  { key: 'matchup', frames: 210 },  // 3.5s
  { key: 'pitcher', frames: 360 },  // 6.0s
  { key: 'winrate', frames: 330 },  // 5.5s
  { key: 'cta', frames: 258 },      // 4.3s
]

export const TOTAL_FRAMES = SCENES.reduce((s, x) => s + x.frames, 0)

/** 각 씬의 시작 프레임 */
export const SCENE_STARTS: Record<SceneKey, number> = (() => {
  const out = {} as Record<SceneKey, number>
  let acc = 0
  for (const s of SCENES) {
    out[s.key] = acc
    acc += s.frames
  }
  return out
})()

/** 씬 전환 크로스페이드 길이 */
export const XFADE = 12

export const SAFE = {
  top: 260,     // 헤더 아래 안전 영역
  bottom: 440,  // 하단 바 + 유튜브 쇼츠 UI 안전 영역
  side: 72,
}
