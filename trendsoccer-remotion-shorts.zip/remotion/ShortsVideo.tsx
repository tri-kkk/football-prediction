// remotion/ShortsVideo.tsx
import React from 'react'
import { AbsoluteFill, Audio, Sequence, staticFile, useCurrentFrame } from 'remotion'
import { ensureFont, FONT_STACK } from './font'
import { SCENES, SCENE_STARTS, TOTAL_FRAMES, XFADE } from './theme'
import { sceneFade } from './anim'
import { Background } from './components/Background'
import { Chrome } from './components/Chrome'
import { SceneCTA, SceneHook, SceneMatchup, ScenePitcher, SceneWinRate } from './scenes/Scenes'
import type { ShortsProps } from './types'

const fontFamily = FONT_STACK

ensureFont()

/** 씬 컨테이너 — 배경 + 내용 + 인/아웃 페이드를 한 덩어리로 묶는다 */
const SceneBox: React.FC<{
  frames: number
  c1: string
  c2: string
  video?: string | null
  children: React.ReactNode
}> = ({ frames, c1, c2, video, children }) => {
  const frame = useCurrentFrame()
  return (
    <AbsoluteFill style={{ opacity: sceneFade(frame, frames, XFADE) }}>
      <Background c1={c1} c2={c2} video={video} durationInFrames={frames} />
      {children}
    </AbsoluteFill>
  )
}

export const ShortsVideo: React.FC<ShortsProps> = ({ game, showLogos, bgm, backgrounds }) => {
  const hc = game.home.c1
  const ac = game.away.c1
  const dur = Object.fromEntries(SCENES.map((s) => [s.key, s.frames])) as Record<string, number>

  return (
    <AbsoluteFill style={{ fontFamily, backgroundColor: '#080c12' }}>
      {bgm ? <Audio src={staticFile(`sounds/${bgm}`)} volume={0.35} /> : null}

      <Sequence from={SCENE_STARTS.hook} durationInFrames={dur.hook}>
        <SceneBox frames={dur.hook} c1={hc} c2={ac} video={backgrounds.hook}>
          <SceneHook game={game} />
        </SceneBox>
      </Sequence>

      <Sequence from={SCENE_STARTS.matchup} durationInFrames={dur.matchup}>
        <SceneBox frames={dur.matchup} c1={hc} c2={ac} video={backgrounds.matchup}>
          <SceneMatchup game={game} showLogos={showLogos} />
        </SceneBox>
      </Sequence>

      <Sequence from={SCENE_STARTS.pitcher} durationInFrames={dur.pitcher}>
        <SceneBox frames={dur.pitcher} c1={hc} c2={ac} video={backgrounds.pitcher}>
          <ScenePitcher game={game} />
        </SceneBox>
      </Sequence>

      <Sequence from={SCENE_STARTS.winrate} durationInFrames={dur.winrate}>
        <SceneBox frames={dur.winrate} c1={hc} c2={ac} video={backgrounds.winrate}>
          <SceneWinRate game={game} />
        </SceneBox>
      </Sequence>

      <Sequence from={SCENE_STARTS.cta} durationInFrames={dur.cta}>
        <SceneBox frames={dur.cta} c1={hc} c2={ac} video={backgrounds.cta}>
          <SceneCTA game={game} />
        </SceneBox>
      </Sequence>

      {/* 전 씬 공통 상·하단 요소 — Sequence 바깥이라 전체 길이 동안 유지 */}
      <Sequence from={0} durationInFrames={TOTAL_FRAMES}>
        <Chrome league={game.league} />
      </Sequence>
    </AbsoluteFill>
  )
}
