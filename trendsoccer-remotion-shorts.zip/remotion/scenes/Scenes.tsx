// remotion/scenes/Scenes.tsx
// 5개 씬 — 전부 1080x1920 네이티브 크기, 프레임 기반 애니메이션

import React from 'react'
import { AbsoluteFill, useCurrentFrame } from 'remotion'
import { BRAND_C1, BRAND_C2, SAFE } from '../theme'
import { fadeUp, fill, glow, pop, slideIn } from '../anim'
import { Crest, Donut, Stars } from '../components/Bits'
import type { Game, TeamMeta } from '../types'

const center: React.CSSProperties = {
  display: 'flex',
  flexDirection: 'column',
  alignItems: 'center',
  justifyContent: 'center',
  color: '#fff',
  padding: `${SAFE.top}px ${SAFE.side}px ${SAFE.bottom}px`,
}

const gradText = (fs: number): React.CSSProperties => ({
  fontSize: fs,
  fontWeight: 900,
  lineHeight: 0.9,
  background: `linear-gradient(135deg, ${BRAND_C1} 0%, ${BRAND_C2} 100%)`,
  WebkitBackgroundClip: 'text',
  WebkitTextFillColor: 'transparent',
  backgroundClip: 'text',
})

export const formatMatchTime = (iso: string): string => {
  try {
    const d = new Date(iso)
    const kst = new Date(d.getTime() + 9 * 3600 * 1000)
    const h = kst.getUTCHours()
    const m = kst.getUTCMinutes()
    const ampm = h < 12 ? '오전' : '오후'
    const hh = h % 12 === 0 ? 12 : h % 12
    return `${kst.getUTCMonth() + 1}월 ${kst.getUTCDate()}일 ${ampm} ${hh}:${String(m).padStart(2, '0')}`
  } catch {
    return iso
  }
}

// ── 1. HOOK ─────────────────────────────────────────────
export const SceneHook: React.FC<{ game: Game }> = ({ game }) => {
  const frame = useCurrentFrame()
  const big = Math.max(game.winRate.home, game.winRate.away)

  return (
    <AbsoluteFill style={center}>
      <div style={{ ...fadeUp(frame, 0), fontSize: 39, color: '#94a3b8', fontWeight: 700, letterSpacing: 9, marginBottom: 24 }}>
        AI가 오늘 이 경기를
      </div>

      <div
        style={{
          ...pop(frame, 6),
          ...gradText(390),
          filter: `drop-shadow(0 0 84px ${BRAND_C1}77)`,
        }}
      >
        {big}
        <span style={{ fontSize: 165 }}>%</span>
      </div>

      <div style={{ ...fadeUp(frame, 26), fontSize: 57, fontWeight: 800, textAlign: 'center', marginTop: 42 }}>
        로 봤습니다.{' '}
        <span style={{ color: BRAND_C1, ...glow(frame, BRAND_C1, BRAND_C2) }}>{game.pick.team} 승</span>
      </div>

      <div style={{ ...fadeUp(frame, 44), marginTop: 54 }}>
        <Stars n={game.pick.stars} size={72} delay={46} />
      </div>
    </AbsoluteFill>
  )
}

// ── 2. MATCHUP ──────────────────────────────────────────
const TeamBlock: React.FC<{ t: TeamMeta; side: string; showLogo: boolean }> = ({ t, side, showLogo }) => (
  <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 27 }}>
    <Crest t={t} showLogo={showLogo} size={300} />
    <div style={{ fontSize: 24, fontWeight: 900, letterSpacing: 6, color: '#64748b' }}>{side}</div>
    <div style={{ fontSize: 57, fontWeight: 900, textAlign: 'center', lineHeight: 1.15 }}>{t.ko}</div>
  </div>
)

export const SceneMatchup: React.FC<{ game: Game; showLogos: boolean }> = ({ game, showLogos }) => {
  const frame = useCurrentFrame()
  return (
    <AbsoluteFill style={center}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 24, width: '100%', justifyContent: 'center' }}>
        <div style={{ flex: 1, ...slideIn(frame, 6, 'left') }}>
          <TeamBlock t={game.home} side="HOME" showLogo={showLogos} />
        </div>
        <div style={{ ...pop(frame, 18), ...gradText(96), letterSpacing: 4, flexShrink: 0 }}>VS</div>
        <div style={{ flex: 1, ...slideIn(frame, 6, 'right') }}>
          <TeamBlock t={game.away} side="AWAY" showLogo={showLogos} />
        </div>
      </div>

      <div style={{ ...fadeUp(frame, 34), marginTop: 96, fontSize: 36, color: '#94a3b8', letterSpacing: 3 }}>
        ⚾ {formatMatchTime(game.matchTime)}
      </div>
    </AbsoluteFill>
  )
}

// ── 3. PITCHER ──────────────────────────────────────────
const StatRow: React.FC<{
  label: string
  home: number | null
  away: number | null
  /** 낮을수록 좋은 지표면 true */
  lowerBetter: boolean
  hc: string
  ac: string
  delay: number
}> = ({ label, home, away, lowerBetter, hc, ac, delay }) => {
  const frame = useCurrentFrame()
  const h = home ?? 0
  const a = away ?? 0

  // 막대 길이는 "값"이 아니라 "우수함"을 나타낸다.
  // ERA·WHIP 처럼 낮을수록 좋은 지표는 그대로 그리면 나쁜 쪽 막대가 더 길어져 반대로 읽힌다.
  const goodness = (v: number) => {
    if (!h || !a) return v ? 100 : 0
    return lowerBetter ? (Math.min(h, a) / v) * 100 : (v / Math.max(h, a)) * 100
  }
  const hw = fill(frame, delay, home == null ? 0 : goodness(h))
  const aw = fill(frame, delay + 5, away == null ? 0 : goodness(a))
  const homeWins = home != null && away != null && (lowerBetter ? h < a : h > a)

  const bar = (w: number, c: string, right: boolean, win: boolean) => (
    <div style={{ flex: 1, height: 33, background: 'rgba(255,255,255,0.06)', borderRadius: 9, overflow: 'hidden', display: 'flex', justifyContent: right ? 'flex-start' : 'flex-end' }}>
      <div
        style={{
          width: `${w}%`,
          height: '100%',
          background: win ? `linear-gradient(90deg, ${BRAND_C1} 0%, ${BRAND_C2} 100%)` : `${c}bb`,
          borderRadius: 9,
          boxShadow: win ? `0 0 24px ${BRAND_C1}66` : undefined,
        }}
      />
    </div>
  )

  return (
    <div style={{ ...fadeUp(frame, delay), display: 'flex', flexDirection: 'column', gap: 12, width: '100%' }}>
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
        <div style={{ fontSize: 42, fontWeight: 900, color: homeWins ? BRAND_C1 : '#e2e8f0', width: 210 }}>
          {home ?? '—'}
        </div>
        <div style={{ fontSize: 27, fontWeight: 800, letterSpacing: 5, color: '#64748b' }}>{label}</div>
        <div style={{ fontSize: 42, fontWeight: 900, color: !homeWins && away != null ? BRAND_C1 : '#e2e8f0', width: 210, textAlign: 'right' }}>
          {away ?? '—'}
        </div>
      </div>
      <div style={{ display: 'flex', gap: 18 }}>
        {bar(hw, hc, false, homeWins)}
        {bar(aw, ac, true, !homeWins && away != null)}
      </div>
    </div>
  )
}

export const ScenePitcher: React.FC<{ game: Game }> = ({ game }) => {
  const frame = useCurrentFrame()
  const p = game.pitchers

  return (
    <AbsoluteFill style={{ ...center, gap: 54 }}>
      <div style={{ ...fadeUp(frame, 0), fontSize: 45, fontWeight: 900, letterSpacing: 8, color: '#94a3b8' }}>
        선발 투수 맞대결
      </div>

      <div style={{ display: 'flex', width: '100%', gap: 24 }}>
        {[
          { t: game.home, name: p?.home.name, from: 'left' as const },
          { t: game.away, name: p?.away.name, from: 'right' as const },
        ].map((x, i) => (
          <div
            key={i}
            style={{
              ...slideIn(frame, 8 + i * 4, x.from, 90),
              flex: 1,
              padding: '30px 24px',
              borderRadius: 30,
              background: `linear-gradient(160deg, ${x.t.c1}66 0%, ${x.t.c1}1f 100%)`,
              border: `3px solid ${x.t.c1}66`,
              display: 'flex',
              flexDirection: 'column',
              alignItems: 'center',
              gap: 12,
            }}
          >
            <div style={{ fontSize: 27, fontWeight: 900, letterSpacing: 4, color: '#cbd5e1' }}>{x.t.ab}</div>
            <div style={{ fontSize: 45, fontWeight: 900, textAlign: 'center', lineHeight: 1.15 }}>
              {x.name || '미정'}
            </div>
          </div>
        ))}
      </div>

      <div style={{ display: 'flex', flexDirection: 'column', gap: 42, width: '100%', marginTop: 24 }}>
        <StatRow label="ERA" home={p?.home.era ?? null} away={p?.away.era ?? null} lowerBetter hc={game.home.c1} ac={game.away.c1} delay={40} />
        <StatRow label="WHIP" home={p?.home.whip ?? null} away={p?.away.whip ?? null} lowerBetter hc={game.home.c1} ac={game.away.c1} delay={70} />
        <StatRow label="K" home={p?.home.k ?? null} away={p?.away.k ?? null} lowerBetter={false} hc={game.home.c1} ac={game.away.c1} delay={100} />
      </div>
    </AbsoluteFill>
  )
}

// ── 4. WIN RATE ─────────────────────────────────────────
export const SceneWinRate: React.FC<{ game: Game }> = ({ game }) => {
  const frame = useCurrentFrame()
  const pickSide = game.pick.side
  const pickPct = pickSide === 'home' ? game.winRate.home : game.winRate.away
  const other = pickSide === 'home' ? game.away : game.home
  const otherPct = pickSide === 'home' ? game.winRate.away : game.winRate.home
  const pickTeam = pickSide === 'home' ? game.home : game.away

  return (
    <AbsoluteFill style={{ ...center, gap: 48 }}>
      <div style={{ ...fadeUp(frame, 0), fontSize: 45, fontWeight: 900, letterSpacing: 8, color: '#94a3b8' }}>
        AI 승리 확률
      </div>

      <div style={{ ...pop(frame, 8) }}>
        <Donut pct={pickPct} size={540} stroke={48} delay={14} label={pickTeam.ko} />
      </div>

      <div style={{ ...fadeUp(frame, 60), display: 'flex', gap: 24, width: '100%' }}>
        {[
          { t: pickTeam, pct: pickPct, hi: true },
          { t: other, pct: otherPct, hi: false },
        ].map((x, i) => (
          <div
            key={i}
            style={{
              flex: 1,
              padding: '27px 24px',
              borderRadius: 27,
              background: x.hi
                ? `linear-gradient(135deg, ${BRAND_C1}2e 0%, ${BRAND_C2}1a 100%)`
                : 'rgba(255,255,255,0.04)',
              border: x.hi ? `3px solid ${BRAND_C1}88` : '3px solid rgba(255,255,255,0.08)',
              display: 'flex',
              flexDirection: 'column',
              alignItems: 'center',
              gap: 9,
            }}
          >
            <div style={{ fontSize: 33, fontWeight: 800, color: '#cbd5e1' }}>{x.t.ko}</div>
            <div style={{ fontSize: 66, fontWeight: 900, color: x.hi ? BRAND_C1 : '#e2e8f0' }}>
              {Math.round(fill(frame, 62, x.pct, 36))}%
            </div>
          </div>
        ))}
      </div>
    </AbsoluteFill>
  )
}

// ── 5. CTA ──────────────────────────────────────────────
export const SceneCTA: React.FC<{ game: Game }> = ({ game }) => {
  const frame = useCurrentFrame()
  return (
    <AbsoluteFill style={{ ...center, gap: 42 }}>
      <div style={{ ...fadeUp(frame, 0), fontSize: 39, color: '#94a3b8', fontWeight: 700, letterSpacing: 8 }}>
        오늘의 PICK
      </div>

      <div
        style={{
          ...pop(frame, 8),
          padding: '48px 72px',
          borderRadius: 36,
          background: `linear-gradient(135deg, ${BRAND_C1}2e 0%, ${BRAND_C2}1a 100%)`,
          border: `4px solid ${BRAND_C1}aa`,
          boxShadow: `0 0 96px ${BRAND_C1}33`,
          display: 'flex',
          flexDirection: 'column',
          alignItems: 'center',
          gap: 18,
        }}
      >
        <div style={{ fontSize: 90, fontWeight: 900, color: BRAND_C1, ...glow(frame, BRAND_C1, BRAND_C2) }}>
          {game.pick.team}
        </div>
        <div style={{ fontSize: 45, fontWeight: 800, color: '#e2e8f0', letterSpacing: 4 }}>
          승리 예측
        </div>
      </div>

      <div style={{ ...fadeUp(frame, 34) }}>
        <Stars n={game.pick.stars} size={66} delay={36} />
      </div>

      <div
        style={{
          ...fadeUp(frame, 56),
          marginTop: 24,
          fontSize: 39,
          color: '#94a3b8',
          textAlign: 'center',
          lineHeight: 1.5,
        }}
      >
        전체 분석과 실시간 배당 흐름은
        <br />
        <span style={{ color: '#fff', fontWeight: 800 }}>trendsoccer.com</span> 에서
      </div>
    </AbsoluteFill>
  )
}
