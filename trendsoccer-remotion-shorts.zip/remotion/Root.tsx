import React from 'react'
import { Composition } from 'remotion'
import { ShortsVideo } from './ShortsVideo'
import { FPS, HEIGHT, TOTAL_FRAMES, WIDTH } from './theme'
import type { ShortsProps } from './types'

const SAMPLE: ShortsProps = {
  showLogos: false,
  bgm: '',
  backgrounds: {
    hook: null,
    matchup: null,
    pitcher: null,
    winrate: null,
    cta: null,
  },
  game: {
    id: 1,
    league: 'KBO',
    home: { ko: 'LG 트윈스', en: 'LG Twins', ab: 'LG', c1: '#C30452', c2: '#000000', logo: '' },
    away: { ko: '한화 이글스', en: 'Hanwha Eagles', ab: 'HH', c1: '#FF6600', c2: '#000000', logo: '' },
    winRate: { home: 63, away: 37 },
    pick: { team: 'LG 트윈스', side: 'home', stars: 4, confidence: 63, grade: 'PICK' },
    pitchers: {
      home: { name: '임찬규', era: 3.42, whip: 1.21, k: 118 },
      away: { name: '문동주', era: 4.15, whip: 1.38, k: 96 },
    },
    aiAnalysis: null,
    matchTime: '2026-08-20T09:30:00.000Z',
    matchDate: '2026-08-20',
    status: 'scheduled',
  },
}

export const RemotionRoot: React.FC = () => (
  <Composition
    id="Shorts"
    component={ShortsVideo}
    durationInFrames={TOTAL_FRAMES}
    fps={FPS}
    width={WIDTH}
    height={HEIGHT}
    defaultProps={SAMPLE}
  />
)
